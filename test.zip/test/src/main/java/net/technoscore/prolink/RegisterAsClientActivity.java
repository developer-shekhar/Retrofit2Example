package net.technoscore.prolink;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.*;
import net.technoscore.prolink.model.ErrorResponse;
import net.technoscore.prolink.util.Utilities;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;


public class RegisterAsClientActivity extends AppCompatActivity implements View.OnClickListener {


    TextInputLayout layoutFName, layoutLName, layoutUserName, layoutUserEmail, layoutPassword, layoutConfPass, layoutPhoneNo;
    EditText edtFName, edtLName, edtUName, edtPass, edtUEmail, edtConfPass, edtPhoneNo;
    TextView txtTeamAndCondition;
    Button btnSignUp;
    ActionBar mActionBar;
    View mCustomView;
    LayoutInflater mInflater;
    Dialog progress;

      CheckBox chkTermMsg;




    String tempFName ;
    String tempLName;
    String tempUName ;
    String tempUEmail;
    String tempPass;
    String tempConfPass ;
    String tempPhoneNo ;


    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_as_client);
        setupactionbar("Sign up");
        init();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();



    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void init() {
        layoutFName = (TextInputLayout) findViewById(R.id.layoutFName);
        layoutLName = (TextInputLayout) findViewById(R.id.layoutLName);
        layoutUserName = (TextInputLayout) findViewById(R.id.layoutUserName);
        layoutUserEmail = (TextInputLayout) findViewById(R.id.layoutUserEmail);
        layoutPassword = (TextInputLayout) findViewById(R.id.layoutPassword);
        layoutConfPass = (TextInputLayout) findViewById(R.id.layoutConfPass);
        layoutPhoneNo = (TextInputLayout) findViewById(R.id.layoutPhoneNo);
        edtFName = (EditText) findViewById(R.id.edtFName);
        edtLName = (EditText) findViewById(R.id.edtLName);
        edtUName = (EditText) findViewById(R.id.edtUName);
        edtUEmail = (EditText) findViewById(R.id.edtUEmail);
        edtPass = (EditText) findViewById(R.id.edtPass);

        edtConfPass = (EditText) findViewById(R.id.edtConfPass);
        edtPhoneNo = (EditText) findViewById(R.id.edtPhoneNo);

        txtTeamAndCondition = (TextView) findViewById(R.id.txtTeamAndCondition);
        btnSignUp = (Button) findViewById(R.id.btnSignUp);

        chkTermMsg= (CheckBox) findViewById(R.id.chkTermMsg);

        btnSignUp.setOnClickListener(this);
        chkTermMsg.setOnClickListener(this);

        txtTeamAndCondition.setOnClickListener(this);

        txtTeamAndCondition.setText(Html.fromHtml(getResources().getString(R.string.txt_term_n_condition)));

        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.txtTeamAndCondition:
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://prolinc.in/terms-and-condition.php"));
                startActivity(intent);

                break;

            case R.id.btnSignUp:
                clientRegister();
                break;
        }
    }

    public void clientRegister() {
         tempFName = edtFName.getText().toString();
         tempLName = edtLName.getText().toString();
         tempUName = edtUName.getText().toString();
         tempUEmail = edtUEmail.getText().toString();
         tempPass = edtPass.getText().toString();
         tempConfPass = edtConfPass.getText().toString();
         tempPhoneNo = edtPhoneNo.getText().toString();

        Boolean flag = false;

        if (tempFName.trim().equals("") || tempLName.trim().equals("") || tempUName.trim().equals("") || tempUEmail.trim().equals("") || tempPass.trim().equals("") ||
                tempConfPass.trim().equals("") || tempPhoneNo.trim().equals("")) {

            if (tempFName.trim().equals("") || tempFName == "" || tempFName == null) {
                flag = false;
                layoutFName.setError("First name should not be blank");
                //layoutFName.setError("");
            } else {
                flag = true;
                layoutFName.setError(null);
            }

            if (tempLName.trim().equals("") || tempLName == "" || tempLName == null) {
                flag = false;
                layoutLName.setError("Last name should not be blank");
                //layoutLName.setError("");
            } else {
                flag = true;
                layoutLName.setError(null);
            }

            if (tempUName.trim().equals("") || tempUName == "" || tempUName == null) {
                flag = false;
                layoutUserName.setError("User name should not be blank");
                //layoutUserName.setError("");
            } else {
                flag = true;
                layoutUserName.setError(null);
            }


            if (tempUEmail.trim().equals("") || tempUEmail == "" || tempUEmail == null) {
                flag = false;
                layoutUserEmail.setError("Email should not be blank");
                //layoutUserEmail.setError("");
            } else {
                flag = true;
                layoutUserEmail.setError(null);
            }
            if (!Utilities.emailValidator(tempUEmail) && tempUEmail.length() > 0) {
                flag = false;
                layoutUserEmail.setError("Email id is not valid");
            } else {
                flag = true;
                layoutUserEmail.setError(null);
            }

            if (tempPass.trim().equals("") || tempPass == "" || tempPass == null || tempPass.length() < 8) {
                flag = false;
                layoutPassword.setError("Password should be minimum 8 character");
                //layoutPassword.setError("");
            } else {
                flag = true;
                layoutPassword.setError(null);
            }

            if (tempConfPass.trim().equals("") || tempConfPass == "" || tempConfPass == null || tempConfPass.length() < 8) {
                flag = false;
                layoutConfPass.setError("Confirm Password should be minimum 8 character");
                //layoutConfPass.setError("");
            } else {
                flag = true;
                layoutConfPass.setError(null);
            }

            if ((tempConfPass.trim().equals(tempPass) || tempConfPass != tempPass) && tempConfPass.length() > 0) {
                flag = false;
                layoutConfPass.setError("Password & Confirm Password is not match");
            } else {
                flag = true;
                layoutConfPass.setError(null);
            }

            if (tempPhoneNo.trim().equals("") || tempPhoneNo == "" || tempPhoneNo == null || tempPhoneNo.length() < 10) {
                flag = false;
                layoutPhoneNo.setError("Phone no. should be 10 digits");
            } else {
                flag = true;
                layoutPhoneNo.setError(null);
            }

        } else if(!chkTermMsg.isChecked())
        {
            Toast.makeText(getApplicationContext(), "Please accept term and condition! ", Toast.LENGTH_SHORT).show();
        }
        else

        {
            progress.show();

            new AsyncTask<String, String, String>(){

                @Override
                protected String doInBackground(String... params) {
                    SinUpClient(tempFName, tempLName, tempUName, tempUEmail, tempPass, tempConfPass, tempPhoneNo);
                    return null;
                }
            }.execute((String) null);

        }

    }


    public static void setErrorTextColor(TextInputLayout textInputLayout, int color) {
        try {
            Field fErrorView = TextInputLayout.class.getDeclaredField("mErrorView");
            fErrorView.setAccessible(true);
            TextView mErrorView = (TextView) fErrorView.get(textInputLayout);
            mErrorView.setTextColor(color);
            mErrorView.requestLayout();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public StringBuilder inputStreamToString(InputStream is) {
        StringBuilder sb = null;

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();

        } catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());

        }
        return sb;

    }

    public void SinUpClient(String tempFName, String tempLName, String tempUName, String tempUEmail,
                            String tempPass, String tempConfPass, String tempPhoneNo) {






  ApiService mApiService = Singleton.getInstance().getApi();

        mApiService.getClientRegister2("VetmH3NVOD4wLpMANbuZ0hJlJpGtBkd1p3xoMK6QVFQ=", tempUName, tempPass,
                tempConfPass, tempFName, tempLName, tempUEmail, tempPhoneNo, "1").enqueue(new Callback<AbstractResponseList<RegistrationMeta, RegistrationData>>() {
            @Override
            public void onResponse(Response<AbstractResponseList<RegistrationMeta, RegistrationData>> response) {


                Log.d("onResponse", response.code() + " msg = "+response.message());
                progress.dismiss();
            }

            @Override
            public void onFailure(Throwable t) {

                Log.d("onFailure", t.getMessage() + "");
                progress.dismiss();

            }
        });




/*


        String apikey= Singleton.getInstance().getEncryptedUID(getApplicationContext());


        mApiService.getClientRegister("VetmH3NVOD4wLpMANbuZ0hJlJpGtBkd1p3xoMK6QVFQ=", tempUName, tempPass,
                tempConfPass, tempFName, tempLName, tempUEmail, tempPhoneNo, "1").enqueue(new Callback<AbstractResponseList<ResponseMetaRegistration, ClientRegisterData>>() {
            @Override
            public void onResponse(Response<AbstractResponseList<ResponseMetaRegistration, ClientRegisterData>> response) {

                ResponseMetaRegistration responseMeta = response.body().getResponseMeta();
                int code = responseMeta.getCode();
                if (code == 402) {
                    List<ErrorResponse> asasa = responseMeta.getErrorResponses();
                    for (int i = 0; i < asasa.size(); i++) {
                        Toast.makeText(getApplicationContext(), asasa.get(i).getError(), Toast.LENGTH_SHORT).show();
                    }
                }else if(code==200)
                {Toast.makeText(getApplicationContext(),"Registration done", Toast.LENGTH_SHORT).show();

                }
                Log.d("Response meta", responseMeta.getMessage() + " "+ responseMeta.getCode() + " "+  responseMeta.getErrorResponses());
                progress.dismiss();
            }

            @Override
            public void onFailure(Throwable t) {
                Log.d("onFailure", t.getMessage() + "");
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progress.dismiss();
            }
        });
*/


    }


    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "RegisterAsClient Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "RegisterAsClient Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
                 client.disconnect();
    }
}
