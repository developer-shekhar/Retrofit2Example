package net.technoscore.prolink.api;


import net.technoscore.prolink.model.AbstractResponse;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.AuthResponse;
import net.technoscore.prolink.model.ClientRegisterData;
import net.technoscore.prolink.model.FindNearMeResultList;
import net.technoscore.prolink.model.ForgotData;
import net.technoscore.prolink.model.ProfRegisterData;
import net.technoscore.prolink.model.RegistrationData;
import net.technoscore.prolink.model.RegistrationMeta;
import net.technoscore.prolink.model.ResponseLogin;
import net.technoscore.prolink.model.ResponseMeta;
import net.technoscore.prolink.model.ResponseMetaRegistration;
import net.technoscore.prolink.model.ResponseMetaSearchNear;
import net.technoscore.prolink.model.TreasurePlan;
import net.technoscore.prolink.model.UAuthentication;
import net.technoscore.prolink.model.UserData;
import net.technoscore.prolink.model.filtermodel.FilterData;
import net.technoscore.prolink.model.queries.MyQueriesCountModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;


/**
 * Created by suntec on 14/01/16.
 */
public interface ApiService {

    @FormUrlEncoded
    @POST("treasureauth")
    Call<AuthResponse> getAuthToken(@Field("uid") String uid);

    @FormUrlEncoded
    @POST("treasureauth")
    Call<AbstractResponse<ResponseMeta, UAuthentication>> getAuthToken2(@Field("uid") String uid);

    @GET("treasure_plan/{token}")
    Call<AbstractResponseList<ResponseMeta, TreasurePlan>> getTreasurePlan(@Path("token") String token);

    @FormUrlEncoded
    @POST("prolincLogin")
    Call<AbstractResponseList<ResponseMeta, UserData>> getLogin(@Field("username") String username, @Field("password") String password, @Field("roleid") String roleid,
                                                                @Field("logintype") String logintype, @Field("remember") String remember);

/*

    @FormUrlEncoded
    @POST("prolincGetAllFilter")
    Call<AbstractResponseList<ResponseMeta, FilterData>> GetFilterData
            (
                    @Field("token") String token,
                    @Field("userid") String userid

            );
*/




    @GET("prolincGetAllFilter")
    Call<AbstractResponseList<ResponseMeta, FilterData>> GetFilterData();


    // ("VetmH3NVOD4wLpMANbuZ0hJlJpGtBkd1p3xoMK6QVFQ=", tempUName, tempPass, tempConfPass, tempFName, tempLName, tempUEmail, tempPhoneNo, "1")
    @FormUrlEncoded
    @POST("prolincUserRegister")
    Call<AbstractResponseList<ResponseMetaRegistration, ClientRegisterData>> getClientRegister(@Field("uid") String uid,
                                                                                               @Field("username") String username,
                                                                                               @Field("password") String password,
                                                                                               @Field("password_confirm") String password_confirm,
                                                                                               @Field("first_name") String first_name,
                                                                                               @Field("last_name") String last_name,
                                                                                               @Field("email") String email,
                                                                                               @Field("phone") String phone,
                                                                                               @Field("terms_condition") String terms_condition);



 @FormUrlEncoded
    @POST("prolincUserRegister")
    Call<AbstractResponseList<RegistrationMeta, RegistrationData>> getClientRegister2(@Field("uid") String uid,
                                                                                               @Field("username") String username,
                                                                                               @Field("password") String password,
                                                                                               @Field("password_confirm") String password_confirm,
                                                                                               @Field("first_name") String first_name,
                                                                                               @Field("last_name") String last_name,
                                                                                               @Field("email") String email,
                                                                                               @Field("phone") String phone,
                                                                                               @Field("terms_condition") String terms_condition);





    @FormUrlEncoded
    @POST("prolincForgotPassword")
    Call<AbstractResponseList<ResponseMeta, ForgotData>> forgotPassword(@Field("token") String token, @Field("emailid") String emailid);

    @FormUrlEncoded
    @POST("prolincFindNearMe")
    Call<AbstractResponseList<ResponseMetaSearchNear, FindNearMeResultList>> findNearMe
            (
                    @Field("token") String token,
                    @Field("userid") String userid,
                    @Field("latitude") String latitude,
                    @Field("longitude") String longitude,
                    @Field("radius") String radius,
                    @Field("srt_by") String srt_by,
                    @Field("limit") String limit,
                    @Field("page") String page,
                    @Field("specialization_search") String specialization_search,
                    @Field("profession_id") String profession_id
            );


    @FormUrlEncoded
    @POST("my_queries_count")
    Call<AbstractResponseList<ResponseMeta, MyQueriesCountModel>> getMyQueriesCount(@Field("token") String token, @Field("user_id") String user_id, @Field("profession") String profession, @Field("startTime") String startTime, @Field("endTime") String endTime, @Field("parent_id") String parent_id, @Field("role") String role);

    @FormUrlEncoded
    @POST("prolincProfRegister")
    Call<AbstractResponseList<ResponseMeta, ProfRegisterData>> ProfRegister(@Field("uid") String userid, @Field("username") String username, @Field("password") String password, @Field("password_confirm") String confpass,
                                                                            @Field("first_name") String firstname, @Field("last_name") String lastname, @Field("email") String email
            , @Field("phone") String phone, @Field("profession") String profession, @Field("qualification") String qualification, @Field("qualifies") String qualifies, @Field("ConsultationFee") String ConsultationFee, @Field("experience") String experience, @Field("packageID") String packageID, @Field("terms_condition") String termcondition);

}

