package net.technoscore.prolink;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import net.technoscore.prolink.model.filtermodel.CheckboxListHelper;
import net.technoscore.prolink.model.filtermodel.DataProfessioanlType;
import net.technoscore.prolink.model.filtermodel.FilterData;
import net.technoscore.prolink.util.GlobalVars;
import net.technoscore.prolink.util.SharedPrefHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vijay on 2/25/2016.
 */
public class SelectTypeActivity extends AppCompatActivity {
    ListView locations;
    ActionBar mActionBar;
    View mCustomView;
    LayoutInflater mInflater;
    SharedPrefHelper sph;
    MyCustomAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selecttypeactivity);
        init();


    }

    public void init() {
        locations = (ListView) findViewById(R.id.listType);
        sph = new SharedPrefHelper(this);
        Gson gsn = new Gson();
        String js = sph.getString("FilterData", "");
        FilterData mFilterData = gsn.fromJson(js, FilterData.class);

        List<DataProfessioanlType> mDataProfessioanlType = mFilterData.getDataProfessioanlType();
        ArrayList<CheckboxListHelper> mCheckboxListHelperList = new ArrayList<CheckboxListHelper>();
        for (int i = 0; i < mDataProfessioanlType.size(); i++) {
            CheckboxListHelper mCheckboxListHelper = new CheckboxListHelper(Integer.parseInt(mDataProfessioanlType.get(i).getId()),
                    mDataProfessioanlType.get(i).getType(), false);
            mCheckboxListHelperList.add(mCheckboxListHelper);

        }
        dataAdapter = new MyCustomAdapter(this, R.layout.profession_list_items, mCheckboxListHelperList);
        locations.setAdapter(dataAdapter);

        setupactionbar("Select Type");


    }


    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // DO SOMETHING HERE
                ArrayList<CheckboxListHelper> countryList = dataAdapter.mCheckboxListHelperList;

                for (int i = 0; i < countryList.size(); i++) {
                    CheckboxListHelper list = countryList.get(i);
                    if (list.isSelected()) {

                        GlobalVars.SelectedType.add(list);
                    }
                }

                SelectTypeActivity.this.finish();
            }
        });
    }


    private class MyCustomAdapter extends ArrayAdapter<CheckboxListHelper> {

        ArrayList<CheckboxListHelper> mCheckboxListHelperList;
        Context ctx;

        public MyCustomAdapter(Context context, int textViewResourceId, ArrayList<CheckboxListHelper> countryList) {
            super(context, textViewResourceId, countryList);
            this.mCheckboxListHelperList = new ArrayList<CheckboxListHelper>();
            this.mCheckboxListHelperList.addAll(countryList);
            this.ctx = context;
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {

                LayoutInflater vi = (LayoutInflater) ctx
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.profession_list_items, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.textView1);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);
                CheckboxListHelper mCheckboxListHelper = mCheckboxListHelperList.get(position);
                holder.code.setText(mCheckboxListHelper.getName());

                holder.name.setChecked(mCheckboxListHelper.isSelected());
                holder.name.setTag(mCheckboxListHelper);
                // holder.code.setText(" (" +  mCheckboxListHelper.getCode() + ")");

                holder.name.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v;
                        CheckboxListHelper listcountry = (CheckboxListHelper) cb.getTag();
                        listcountry.setSelected(cb.isChecked());
                        int id = mCheckboxListHelperList.get(position).getCode();


                    }
                });
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            return convertView;

        }

    }

    @Override
    public void onBackPressed() {

    }
}

