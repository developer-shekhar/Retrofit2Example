package net.technoscore.prolink;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Vijay on 3/4/2016.
 */
public class ProfessinalSettingActivity extends AppCompatActivity implements View.OnClickListener {

TextView txtUpdateBasicInfo;
    TextView txtChangePassword;
    TextView txtChangePhoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.professinal_setting_activity);
        init();
    }

    private void init()
    {
        txtUpdateBasicInfo=(TextView)findViewById(R.id.txtUpdateBasicInfo);
        txtUpdateBasicInfo.setOnClickListener(this);
        txtChangePassword=(TextView)findViewById(R.id.txtChangePassword);
        txtChangePassword.setOnClickListener(this);
        txtChangePhoneNumber=(TextView)findViewById(R.id.txtChangePhoneNumber);
        txtChangePhoneNumber.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.txtUpdateBasicInfo:

                break;
            case R.id.txtChangePassword:

                break;
            case R.id.txtChangePhoneNumber:

                break;
        }

    }
}
