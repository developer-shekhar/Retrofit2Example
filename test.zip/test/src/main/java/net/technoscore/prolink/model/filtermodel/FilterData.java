
package net.technoscore.prolink.model.filtermodel;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class FilterData {

    @SerializedName("dataProfessioanlType")

    private List<DataProfessioanlType> dataProfessioanlType = new ArrayList<DataProfessioanlType>();
    @SerializedName("dataSpecialist")

    private List<DataSpecialist> dataSpecialist = new ArrayList<DataSpecialist>();
    @SerializedName("dataSortByDistance")

    private List<DataSortByDistance> dataSortByDistance = new ArrayList<DataSortByDistance>();
    @SerializedName("dataSortBy")

    private List<DataSortBy> dataSortBy = new ArrayList<DataSortBy>();
    @SerializedName("dataFilterByExperience")

    private List<DataFilterByExperience> dataFilterByExperience = new ArrayList<DataFilterByExperience>();

    /**
     * @return The dataProfessioanlType
     */
    public List<DataProfessioanlType> getDataProfessioanlType() {
        return dataProfessioanlType;
    }

    /**
     * @param dataProfessioanlType The dataProfessioanlType
     */
    public void setDataProfessioanlType(List<DataProfessioanlType> dataProfessioanlType) {
        this.dataProfessioanlType = dataProfessioanlType;
    }

    /**
     * @return The dataSpecialist
     */
    public List<DataSpecialist> getDataSpecialist() {
        return dataSpecialist;
    }

    /**
     * @param dataSpecialist The dataSpecialist
     */
    public void setDataSpecialist(List<DataSpecialist> dataSpecialist) {
        this.dataSpecialist = dataSpecialist;
    }

    /**
     * @return The dataSortByDistance
     */
    public List<DataSortByDistance> getDataSortByDistance() {
        return dataSortByDistance;
    }

    /**
     * @param dataSortByDistance The dataSortByDistance
     */
    public void setDataSortByDistance(List<DataSortByDistance> dataSortByDistance) {
        this.dataSortByDistance = dataSortByDistance;
    }

    /**
     * @return The dataSortBy
     */
    public List<DataSortBy> getDataSortBy() {
        return dataSortBy;
    }

    /**
     * @param dataSortBy The dataSortBy
     */
    public void setDataSortBy(List<DataSortBy> dataSortBy) {
        this.dataSortBy = dataSortBy;
    }

    /**
     * @return The dataFilterByExperience
     */
    public List<DataFilterByExperience> getDataFilterByExperience() {
        return dataFilterByExperience;
    }

    /**
     * @param dataFilterByExperience The dataFilterByExperience
     */
    public void setDataFilterByExperience(List<DataFilterByExperience> dataFilterByExperience) {
        this.dataFilterByExperience = dataFilterByExperience;
    }

}
