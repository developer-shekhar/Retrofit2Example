package net.technoscore.prolink;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.ClientRegisterData;
import net.technoscore.prolink.model.ForgotData;
import net.technoscore.prolink.model.ResponseMeta;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Vijay on 3/1/2016.
 */
public class ForgotPasswordActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edtEmail;
    private Button btnEmailSubmit;
    ProgressDialog dialog;
    TextInputLayout layoutEmail;
    Dialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_password);
        dialog = new ProgressDialog(ForgotPasswordActivity.this);
        setupactionbar("Forget Password");
        init();
    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init() {

        layoutEmail = (TextInputLayout) findViewById(R.id.layoutEmail);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        btnEmailSubmit = (Button) findViewById(R.id.btnEmailSubmit);
        btnEmailSubmit.setOnClickListener(this);

        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
    }

    @Override
    public void onClick(View v) {


        switch (v.getId()) {
            case R.id.btnEmailSubmit:
                forgotPassword();
                break;
        }

    }

    private void forgotPassword() {
        final String email = edtEmail.getText().toString();

        if (email.trim().equals("") || email == "" || email == null) {

            layoutEmail.setError("Email should not be blank");
        } else {
            layoutEmail.setError(null);
        }

        if (emailValidator(email) && email.length() > 0) {
            layoutEmail.setError(null);
            progress.show();
            ApiService mApiService = Singleton.getInstance().getApi();
            mApiService.forgotPassword("5f8d4f62b649e18c83e71455600766", email).
                    enqueue(new Callback<AbstractResponseList<ResponseMeta, ForgotData>>() {
                        @Override
                        public void onResponse(Response<AbstractResponseList<ResponseMeta, ForgotData>> response) {
                            ResponseMeta responseMeta = response.body().getResponseMeta();
                            progress.dismiss();
                            int code = responseMeta.getCode();
                            Log.d("checkresponce", "***" + email);

                            if (code == 200) {
                                Toast.makeText(ForgotPasswordActivity.this, response.body().getData().get(0).getMessage(), Toast.LENGTH_SHORT).show();

                                startActivity(new Intent(ForgotPasswordActivity.this, OTPVerificationActivity.class));
                            } else {
                                Toast.makeText(ForgotPasswordActivity.this, responseMeta.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Throwable t) {
                            Log.d("getLogin", "error = " + t.getMessage());
                            progress.dismiss();
                        }
                    });
        } else {
            layoutEmail.setError("Email is not valid");
        }
    }


    public boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}