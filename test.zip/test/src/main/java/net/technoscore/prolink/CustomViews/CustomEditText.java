package net.technoscore.prolink.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.EditText;

import net.technoscore.prolink.R;

public class CustomEditText extends EditText {

    public CustomEditText(Context context) {
        super(context);
        FontUtils.setFontFace(context, this, "NORMAL");
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        if (!isInEditMode()) {

            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView, 0, 0);
            String fontName = a.getString(R.styleable.CustomTextView_customFont);
            a.recycle();

            if (fontName != null)
                FontUtils.setFontFace(context, this, fontName);
            else FontUtils.setFontFace(context, this, "NORMAL");
        }
    }
}