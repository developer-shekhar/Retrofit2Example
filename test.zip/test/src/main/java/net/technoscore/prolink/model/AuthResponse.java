package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by suntec on 18/01/16.
 */

public class AuthResponse {

    // used for error handling
    @SerializedName("response_meta")
    private ResponseMeta responseMeta;

    @SerializedName("data")
    private  UAuthentication resposeData;


    public ResponseMeta getResponseMeta() {
        return responseMeta;
    }

    public void setResponseMeta(ResponseMeta responseMeta) {
        this.responseMeta = responseMeta;
    }

    public UAuthentication getResposeData() {
        return resposeData;
    }

    public void setResposeData(UAuthentication resposeData) {
        this.resposeData = resposeData;
    }
}