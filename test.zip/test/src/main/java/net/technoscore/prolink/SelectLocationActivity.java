package net.technoscore.prolink;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.CharacterPickerDialog;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import net.technoscore.prolink.model.InfoPoint;
import net.technoscore.prolink.model.filtermodel.CheckboxListHelper;
import net.technoscore.prolink.model.filtermodel.Locationhelper;
import net.technoscore.prolink.util.GlobalVars;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by Vijay on 2/25/2016.
 */
public class SelectLocationActivity extends AppCompatActivity  {

    //   Spinner spnProfessional, spnDistance;
    AutoCompleteTextView edtLocation;
    private ArrayAdapter<String> LocationAdapter;
    private ArrayAdapter<String> mArrayAdapter;
    GetPlaces task;

    ListView locations;
    RelativeLayout sort_linear_layout;
    private LocationManager locationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selectlocationactivity);
        setupactionbar("Select Location");
        init();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
       // locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10, this);


    }

    @Override
    public void onBackPressed() {

    }

    public void init() {
        edtLocation = (AutoCompleteTextView) findViewById(R.id.edtLocation);
        locations = (ListView) findViewById(R.id.listLocations);
        sort_linear_layout= (RelativeLayout) findViewById(R.id.sort_linear_layout);

        LocationAdapter = new ArrayAdapter<String>(this,
                R.layout.location_items);
        LocationAdapter.setNotifyOnChange(true);
        edtLocation.setAdapter(LocationAdapter);
        TextChangedListener(edtLocation, LocationAdapter);

        locations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String value = (String) parent.getItemAtPosition(position);
                GlobalVars.Location = value;

                value = URLEncoder.encode(value);
                 new GetLatLong(value).execute((String)null);
                SelectLocationActivity.this.finish();
            }
        });


    }

    public class GetLatLong extends AsyncTask<String, String, String> {
        String Address;

        GetLatLong(String Address) {
            this.Address = Address;
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                URL googlePlaces = new URL("https://maps.googleapis.com/maps/api/geocode/json?address=" + Address + "&key=AIzaSyD0wGRNY2M8567kLjTuOPn3BFOKNuGe_K0");
                URLConnection tc = googlePlaces.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        tc.getInputStream()));

                String line;

                StringBuffer sb = new StringBuffer();
                // take Google's legible JSON and turn it into one big string.
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                }

                ArrayList<InfoPoint> data=  parsePoints(sb.toString());
                Toast.makeText(getApplicationContext(),  data.get(0).getDblLatitude() +" "+ data.get(0).getDblLongitude(), Toast.LENGTH_SHORT).show();

            } catch (IOException e) {
                Log.e("YourApp", "GetPlaces : doInBackground", e);

                Log.d("error", e.getMessage());

            }
            catch (Exception e)
            {

            }
            return null;
        }
    }




    private ArrayList<InfoPoint> parsePoints(String strResponse) {
        // TODO Auto-generated method stub
        ArrayList<InfoPoint> result = new ArrayList<InfoPoint>();
        try {
            JSONObject obj = new JSONObject(strResponse);
            JSONArray array = obj.getJSONArray("results");
            for (int i = 0; i < array.length(); i++) {
                InfoPoint point = new InfoPoint();

                JSONObject item = array.getJSONObject(i);
                ArrayList<HashMap<String, Object>> tblPoints = new ArrayList<HashMap<String, Object>>();
                JSONArray jsonTblPoints = item.getJSONArray("address_components");
                for (int j = 0; j < jsonTblPoints.length(); j++) {
                    JSONObject jsonTblPoint = jsonTblPoints.getJSONObject(j);
                    HashMap<String, Object> tblPoint = new HashMap<String, Object>();
                    Iterator<String> keys = jsonTblPoint.keys();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        if (tblPoint.get(key) instanceof JSONArray) {
                            tblPoint.put(key, jsonTblPoint.getJSONArray(key));
                        }
                        tblPoint.put(key, jsonTblPoint.getString(key));
                    }
                    tblPoints.add(tblPoint);
                }
                point.setAddressFields(tblPoints);
                point.setStrFormattedAddress(item.getString("formatted_address"));
                JSONObject geoJson = item.getJSONObject("geometry");
                JSONObject locJson = geoJson.getJSONObject("location");
                point.setDblLatitude(Double.parseDouble(locJson.getString("lat")));
                point.setDblLongitude(Double.parseDouble(locJson.getString("lng")));

                result.add(point);
            }
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }

    public void BindSpinners(Spinner spinner, ArrayList<String> dataList) {
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapterDistance = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
                dataList);
        // Drop down layout style - list view with radio button
        dataAdapterDistance.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapterDistance);
    }


    private void TextChangedListener(final AutoCompleteTextView EditLocation, final ArrayAdapter<String> adapter) {
        // TODO Auto-generated method stub
        EditLocation.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                // TODO Auto-generated method stub
                if (count % 3 == 1) {

                    Log.d("Data", EditLocation.getText().toString());
                    adapter.clear();
                    mArrayAdapter = adapter;
                    task = new GetPlaces(EditLocation.getText().toString(),
                            EditLocation);

                    task.execute((Locationhelper) null);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });
    }

    private class GetPlaces extends
            AsyncTask<Locationhelper, Void, ArrayList<Locationhelper>> {
        String searchString = "";

        AutoCompleteTextView PlaceEditLocation;

        GetPlaces(String searchText, AutoCompleteTextView editLocation) {
            searchString = searchText;
            PlaceEditLocation = editLocation;
        }

        @Override
        // three dots is java for an array of strings
        protected ArrayList<Locationhelper> doInBackground(
                Locationhelper... args) {
            //   Log.d("gottaGo", "doInBackground");
            ArrayList<Locationhelper> predictionsArr = new ArrayList<Locationhelper>();
            try {
                // https://maps.googleapis.com/maps/api/place/autocomplete/json?input=Delhi&key=AIzaSyBN43li9BMtXBKfCVujxzUZH2IMlCUQF9g
                URL googlePlaces = new URL(
                        "https://maps.googleapis.com/maps/api/place/autocomplete/json?input="
                                + URLEncoder.encode(searchString.toString(),
                                "UTF-8")
                                + "&components=country:in&types:['(cities)']&key=AIzaSyBN43li9BMtXBKfCVujxzUZH2IMlCUQF9g");
                URLConnection tc = googlePlaces.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        tc.getInputStream()));

                String line;

                StringBuffer sb = new StringBuffer();
                // take Google's legible JSON and turn it into one big string.
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                }

                Log.d("Message", sb.toString());
                // turn that string into a JSON object
                JSONObject predictions = new JSONObject(sb.toString());
                // now get the JSON array that's inside that object
                JSONArray ja = new JSONArray(
                        predictions.getString("predictions"));

                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jo = (JSONObject) ja.get(i);
                    // add each entry to our array
                    Locationhelper location = new Locationhelper();
                    location.setAddress(jo.getString("description"));

                    JSONArray statecity = jo.getJSONArray("terms");
                    /*
                     * for(int k=0; k< statecity.length(); k++) {
					 */
                    if (statecity.length() == 3) {
                        location.setStateName(statecity.getString(1));
                    } else if (statecity.length() == 2) {
                        location.setStateName(statecity.getString(0));
                    }
                    // }

                    predictionsArr.add(location);

                }
            } catch (IOException e) {
                Log.e("YourApp", "GetPlaces : doInBackground", e);

            } catch (JSONException e) {
                Log.e("YourApp", "GetPlaces : doInBackground", e);

            }
            return predictionsArr;

        }

        // then our post

        @Override
        protected void onPostExecute(ArrayList<Locationhelper> result) {
            Log.d("YourApp", "onPostExecute : " + result.size());
            // update the adapter
            mArrayAdapter = new ArrayAdapter<String>(SelectLocationActivity.this, R.layout.location_items);
            mArrayAdapter.setNotifyOnChange(true);
            // attach the adapter to textview
            //PlaceEditLocation.setAdapter(mArrayAdapter);

            locations.setAdapter(mArrayAdapter);
            for (int i = 0; i < result.size(); i++) {
                mArrayAdapter.add(result.get(i).getAddress());
                mArrayAdapter.notifyDataSetChanged();
            }
            PlaceEditLocation
                    .setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent,
                                                   View view, int position, long id) {
                            // TODO Auto-generated method stub

                            Locationhelper location = (Locationhelper) PlaceEditLocation
                                    .getAdapter().getItem(position);

                            Toast.makeText(getApplicationContext(), location.getAddress(), Toast.LENGTH_SHORT).show();


                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                            // TODO Auto-generated method stub

                        }
                    });
            Log.d("YourApp", "onPostExecute : autoCompleteAdapter"
                    + mArrayAdapter.getCount());

        }

    }



    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


}
