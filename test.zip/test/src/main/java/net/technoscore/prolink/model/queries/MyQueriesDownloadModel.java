package net.technoscore.prolink.model.queries;

/**
 * Created by Vijay on 3/2/2016.
 */
public class MyQueriesDownloadModel {

    private String file;

    public String getFile ()
    {
        return file;
    }

    public void setFile (String file)
    {
        this.file = file;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [file = "+file+"]";
    }
}
