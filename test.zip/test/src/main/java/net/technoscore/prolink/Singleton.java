package net.technoscore.prolink;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.util.Log;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.User;
import net.technoscore.prolink.util.MCrypt;

import java.util.Calendar;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.GsonConverterFactory;
import retrofit2.Retrofit;


/**
 * Created by suntec on 14/01/16.
 */
public class Singleton {

    Context mContext;
    private static Singleton ourInstance = new Singleton();

    public static Singleton getInstance() {
        return ourInstance;
    }

    private Singleton() {
    }

    private User mUser;

    public ApiService getApi() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();


        Retrofit retrofit = new Retrofit.Builder()
                //.baseUrl("http://prolinc.in/prolincApi/")
                .client(client)
                .baseUrl("http://192.168.1.87/prolinc/prolincApi/")
                .addConverterFactory(GsonConverterFactory.create())
               /* .addConverterFactory(GsonConverterFactory.create(gson))*/
                .build();

        return retrofit.create(ApiService.class);

    }

    public void printLog(String tag, String msg) {

        Log.d(tag, msg);

    }

    public String getMD5(String md5) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(md5.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
        }
        return null;
    }


    public User getmUser() {
        return mUser;
    }

    public void setmUser(User mUser) {
        this.mUser = mUser;
    }


    public String getWordCaptiple(String str) {

        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }


    public boolean isNetworkAvailable(Context mContext) {

        ConnectivityManager connectivityManager
                = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public String getAndroidId(Context mContext){
        String androidId = Settings.Secure.getString(mContext.getContentResolver(),
                Settings.Secure.ANDROID_ID);
        return androidId;
    }


    /*public String getEncryptedUID(Context mContext){

        MCrypt mcrypt = new MCrypt();
        String encryptedKey =  "aMtN60U1q5tz6uZXaHZzkoh/W1fzBO+xBZ2apWIUyEU="; // default
        try {
            String toEncrypt = "salt+" + Calendar.getInstance().getTimeInMillis() + getAndroidId(mContext);

            encryptedKey = MCrypt.bytesToHex( mcrypt.encrypt(toEncrypt) );

        } catch (Exception e) {
            e.printStackTrace();
        }

        return  encryptedKey;
    }
*/
    public String getEncryptedUID(Context mContext){

        MCrypt mcrypt = new MCrypt();
        String encryptedKey =  "aMtN60U1q5tz6uZXaHZzkoh/W1fzBO+xBZ2apWIUyEU="; // default
        try {

            String toEncrypt = "salt#"+getAndroidId(mContext)+"#"+Calendar.getInstance().getTimeInMillis()+"#sha";
            encryptedKey = MCrypt.bytesToHex( mcrypt.encrypt(toEncrypt) );

        } catch (Exception e) {
            e.printStackTrace();
        }


      //  printLog("Singleton", getDecryptKey(encryptedKey));

        return  encryptedKey;

    }

}
