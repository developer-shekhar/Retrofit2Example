package net.technoscore.prolink;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;


import net.technoscore.prolink.adapter.ProfessionListAdapter;
import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;

import net.technoscore.prolink.model.ResponseMeta;
import net.technoscore.prolink.model.queries.MyQueriesCountModel;
import net.technoscore.prolink.model.queries.ProfDashboardModel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by suntec on 2/3/16.
 */
public class ProfessionalDashboard extends AppCompatActivity implements View.OnClickListener {

    TextView txtUserName, txtNewQuries, txtAllQuery, txtWaitQuery, txtinterested, txtAnswer, txtBookMark;
    Dialog progress;
    RelativeLayout relSetting,relCase,relAppoint;
    ImageView imgProfilePic, imgEditPic;
    RecyclerView recycleProfession;
    ProfessionListAdapter recycleProfAdapter;
    List<ProfDashboardModel> profDashList;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.professional_dashboard);
        setupactionbar("Dashboard");
        init();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init() {

        txtUserName = (TextView) findViewById(R.id.txtUserName);
        relAppoint = (RelativeLayout) findViewById(R.id.relAppoint);
        relCase = (RelativeLayout) findViewById(R.id.relCase);
        relSetting = (RelativeLayout) findViewById(R.id.relSetting);
        txtNewQuries = (TextView) findViewById(R.id.txtNewQuries);
        txtAllQuery = (TextView) findViewById(R.id.txtAllQuery);
        txtWaitQuery = (TextView) findViewById(R.id.txtWaitQuery);
        txtinterested = (TextView) findViewById(R.id.txtinterested);
        txtAnswer = (TextView) findViewById(R.id.txtAnswer);
        txtBookMark = (TextView) findViewById(R.id.txtBookMark);
        imgEditPic = (ImageView) findViewById(R.id.imgEditPic);
        imgProfilePic = (ImageView) findViewById(R.id.imgProfilePic);
        recycleProfession = (RecyclerView) findViewById(R.id.recycleProfession);

        recycleProfession.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        recycleProfession.setLayoutManager(mLayoutManager);
        recycleProfession.setItemAnimator(new DefaultItemAnimator());

        relAppoint.setOnClickListener(this);
        relCase.setOnClickListener(this);
        relSetting.setOnClickListener(this);
        txtNewQuries.setOnClickListener(this);
        txtAllQuery.setOnClickListener(this);
        txtWaitQuery.setOnClickListener(this);
        txtinterested.setOnClickListener(this);
        txtAnswer.setOnClickListener(this);
        txtBookMark.setOnClickListener(this);
        imgEditPic.setOnClickListener(this);

        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        profDashList = new ArrayList<ProfDashboardModel>();

        for (int i = 0; i < 8; i++) {

            ProfDashboardModel data = new ProfDashboardModel();

            data.setQuery_message("fj dsfsdf ds hfod sfdsjf sd fds");
            data.setQuery_file("fj dsfsdf ds hfod sfdsjf sd fds");

            profDashList.add(data);
        }

        getQuriesCount();


        recycleProfAdapter = new ProfessionListAdapter(ProfessionalDashboard.this, profDashList);
        recycleProfession.setAdapter(recycleProfAdapter);
    }


    public void getQuriesCount() {

        ApiService mApiService = Singleton.getInstance().getApi();
        mApiService.getMyQueriesCount("5f8d4f62b649e18c83e71455600766", "1084", "advocate", "00", "00", "111", "2").
                enqueue(new Callback<AbstractResponseList<ResponseMeta, MyQueriesCountModel>>() {
                    @Override
                    public void onResponse(Response<AbstractResponseList<ResponseMeta, MyQueriesCountModel>> response) {
                        ResponseMeta responseMeta = response.body().getResponseMeta();

                        int code = responseMeta.getCode();

                        if (code == 200) {
                            Toast.makeText(ProfessionalDashboard.this, responseMeta.getMessage(), Toast.LENGTH_SHORT).show();

                            txtNewQuries.setText("New Queries (" + response.body().getData().get(0).getTotal_query() + ")");
                            txtAllQuery.setText("All Queries (" + response.body().getData().get(0).getTotal_query() + ")");
                            txtWaitQuery.setText("Queries in Waiting (" + response.body().getData().get(0).getTotal_query() + ")");
                            txtinterested.setText("Interested (" + response.body().getData().get(0).getTotal_interest() + ")");
                            txtAnswer.setText("Answered (" + response.body().getData().get(0).getTotal_answer() + ")");
                            txtBookMark.setText("Bookmarded Queries (" + response.body().getData().get(0).getTotal_query() + ")");

                        } else {
                            Toast.makeText(ProfessionalDashboard.this, responseMeta.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        Log.d("getLogin", "error = " + t.getMessage());
                    }
                });

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.relAppoint:
                //startActivity(new Intent(ProfessionalDashboard.this,FindProfessionActivity.class));
                break;
            case R.id.relCase:
                //startActivity(new Intent(ProfessionalDashboard.this,FindProfessionActivity.class));
                break;
            case R.id.relSetting:
                //startActivity(new Intent(ProfessionalDashboard.this,FindProfessionActivity.class));
                break;
            case R.id.txtNewQuries:
                break;
            case R.id.txtAllQuery:
                break;
            case R.id.txtWaitQuery:
                break;
            case R.id.txtinterested:
                break;
            case R.id.txtAnswer:
                break;
            case R.id.txtBookMark:
                break;
            case R.id.imgEditPic:
                dispatchTakePictureIntent();
                break;

        }

    }


    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();

            Bitmap imageBitmap = (Bitmap) extras.get("data");

            imgProfilePic.setImageBitmap(getRoundedShape(imageBitmap));

            String imagepath = SaveImage(imageBitmap);
            Log.d("Image Path", imagepath);
            // images=getBytesFromBitmap(imageBitmap);
            final String images = encodeTobase64(imageBitmap);
            /*new AsyncTask<String, String, String>() {

                @Override
                protected String doInBackground(String... params) {
                    // TODO Auto-generated method stub
                    int UserId = sph.getInt("UserId", 0);
                    // , , ""
                    serviceHelper.UploadUserImage("InsertPicture",
                            sph.getString("usernameOrEmail", ""),
                            sph.getString("password", ""), "554545454dfdfd5",
                            "", UserId + "", images, "image/jpeg", "test", "0");

                    return null;
                }

            }.execute((String) null);*/
        }
    }

    public Bitmap getRoundedShape(Bitmap scaleBitmapImage) {
        int targetWidth = 50;
        int targetHeight = 50;
        Bitmap targetBitmap = Bitmap.createBitmap(targetWidth,
                targetHeight, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(targetBitmap);
        Path path = new Path();
        path.addCircle(((float) targetWidth - 1) / 2,
                ((float) targetHeight - 1) / 2,
                (Math.min(((float) targetWidth),
                        ((float) targetHeight)) / 2),
                Path.Direction.CCW);

        canvas.clipPath(path);
        Bitmap sourceBitmap = scaleBitmapImage;
        canvas.drawBitmap(sourceBitmap,
                new Rect(0, 0, sourceBitmap.getWidth(),
                        sourceBitmap.getHeight()),
                new Rect(0, 0, targetWidth, targetHeight), null);
        return targetBitmap;
    }

    private String encodeTobase64(Bitmap image) {
        Bitmap immagex = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.PNG, 25, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);
        return imageEncoded;
    }

    public byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        return stream.toByteArray();
    }

    private String SaveImage(Bitmap finalBitmap) {

        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/saved_images");
        myDir.mkdirs();

        String fname = "temp_user.jpg";
        File file = new File(myDir, fname);
        if (file.exists())
            file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return root + "/saved_images/" + "temp_user.jpg";
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "ProfessionalDashboard Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "ProfessionalDashboard Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}
