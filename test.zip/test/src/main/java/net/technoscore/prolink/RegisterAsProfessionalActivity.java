package net.technoscore.prolink;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.ClientRegisterData;
import net.technoscore.prolink.model.ProfRegisterData;
import net.technoscore.prolink.model.ResponseMeta;
import net.technoscore.prolink.model.filtermodel.DataProfessioanlType;
import net.technoscore.prolink.model.filtermodel.DataSpecialist;
import net.technoscore.prolink.model.filtermodel.FilterData;
import net.technoscore.prolink.util.SharedPrefHelper;
import net.technoscore.prolink.util.Utilities;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Vijay on 2/19/2016.
 */
public class RegisterAsProfessionalActivity extends AppCompatActivity implements View.OnClickListener {

    TextInputLayout layoutFName, layoutLName, layoutUserName, layoutUserEmail, layoutPassword, layoutConfPass, layoutPhoneNo,layoutQualifyYr,layoutExperience,layoutConsultationFee;
    EditText edtFName, edtLName, edtUName, edtPass, edtUEmail, edtConfPass, edtPhoneNo,edtQualifyYr,edtExperience,edtConsultationFee;
    TextView txtTeamAndCondition;
    Button btnSignUp;
    Dialog progress;
    Spinner spinProfession, spinSpecilization;
    String strProfession, strSpecilization,strProfessionID, strSpecilizationID;
    SharedPrefHelper sph;
    ArrayList<String> listProfession,listSpecilization;
    List<DataProfessioanlType> mDataProfessioanlType;
    List<DataSpecialist> mDataSpecialist;

    CheckBox chkTermMsg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_as_professional);
        setupactionbar("Sign up");
        init();

    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void init() {
        layoutFName = (TextInputLayout) findViewById(R.id.layoutFName);
        layoutLName = (TextInputLayout) findViewById(R.id.layoutLName);
        layoutUserName = (TextInputLayout) findViewById(R.id.layoutUserName);
        layoutUserEmail = (TextInputLayout) findViewById(R.id.layoutUserEmail);
        layoutPassword = (TextInputLayout) findViewById(R.id.layoutPassword);
        layoutConfPass = (TextInputLayout) findViewById(R.id.layoutConfPass);
        layoutPhoneNo = (TextInputLayout) findViewById(R.id.layoutPhoneNo);

        layoutQualifyYr = (TextInputLayout) findViewById(R.id.layoutQualifyYr);
        layoutExperience = (TextInputLayout) findViewById(R.id.layoutExperience);
        layoutConsultationFee = (TextInputLayout) findViewById(R.id.layoutConsultationFee);

        spinProfession = (Spinner) findViewById(R.id.spinProfession);
        spinSpecilization = (Spinner) findViewById(R.id.spinSpecilization);

        chkTermMsg= (CheckBox) findViewById(R.id.chkTermMsg);
        chkTermMsg.setOnClickListener(this);

        edtFName = (EditText) findViewById(R.id.edtFName);
        edtLName = (EditText) findViewById(R.id.edtLName);
        edtUName = (EditText) findViewById(R.id.edtUName);
        edtUEmail = (EditText) findViewById(R.id.edtUEmail);
        edtPass = (EditText) findViewById(R.id.edtPass);
        edtQualifyYr = (EditText) findViewById(R.id.edtQualifyYr);
        edtExperience = (EditText) findViewById(R.id.edtExperience);
        edtConfPass = (EditText) findViewById(R.id.edtConfPass);
        edtPhoneNo = (EditText) findViewById(R.id.edtPhoneNo);

        edtConsultationFee = (EditText) findViewById(R.id.edtConsultationFee);


        txtTeamAndCondition = (TextView) findViewById(R.id.txtTeamAndCondition);
        btnSignUp = (Button) findViewById(R.id.btnSignUp);

        btnSignUp.setOnClickListener(this);

        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));


        spinProfession.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView adapter, View v, int i, long lng) {

                strProfession = adapter.getItemAtPosition(i).toString();
                //or this can be also right: selecteditem = level[i];

                if (i != 0)
                    strProfessionID = mDataProfessioanlType.get(i - 1).getId();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });


        spinSpecilization.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView adapter, View v, int i, long lng) {

                strSpecilization = adapter.getItemAtPosition(i).toString();
                if (i != 0)
                    strSpecilizationID = mDataSpecialist.get(i - 1).getId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

       loadSpecification();
       loadProfession();

    }

    public void loadProfession()
    {
        listProfession=new ArrayList<String>();
        listProfession.clear();
        sph = new SharedPrefHelper(this);
        Gson gsn = new Gson();
        String js = sph.getString("FilterData", "");
        FilterData mFilterData = gsn.fromJson(js, FilterData.class);


        listProfession.add("Profession");
        mDataProfessioanlType= mFilterData.getDataProfessioanlType();
        for(int i=0; i< mDataProfessioanlType.size(); i++)
        {
            //Toast.makeText(getApplicationContext(), mDataProfessioanlType.get(i).getType(), Toast.LENGTH_SHORT).show();
            listProfession.add(mDataProfessioanlType.get(i).getType());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.custom_spinner_textveiw,R.id.tv_promo_txt,listProfession);
        spinProfession.setAdapter(adapter);

    }

    public void loadSpecification()
    {
        listSpecilization=new ArrayList<String>();
        listSpecilization.clear();
        sph = new SharedPrefHelper(this);
        Gson gsn = new Gson();
        String js = sph.getString("FilterData", "");
        FilterData mFilterData = gsn.fromJson(js, FilterData.class);
        listSpecilization.add("Specilization");
        mDataSpecialist= mFilterData.getDataSpecialist();
        for(int i=0; i< mDataSpecialist.size(); i++)
        {
            //Toast.makeText(getApplicationContext(), mDataSpecialist.get(i).getLabel(), Toast.LENGTH_SHORT).show();
            listSpecilization.add(mDataSpecialist.get(i).getLabel());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.custom_spinner_textveiw,R.id.tv_promo_txt,listSpecilization);
        spinSpecilization.setAdapter(adapter);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.txtTeamAndCondition:
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://prolinc.in/terms-and-condition.php"));
                startActivity(intent);

            case R.id.btnSignUp:
                clientRegister();
                break;
        }
    }

    public void clientRegister() {
        String tempFName = edtFName.getText().toString();
        String tempLName = edtLName.getText().toString();
        String tempUName = edtUName.getText().toString();
        String tempUEmail = edtUEmail.getText().toString();
        String tempPass = edtPass.getText().toString();
        String tempConfPass = edtConfPass.getText().toString();
        String tempPhoneNo = edtPhoneNo.getText().toString();

        String tempQualifyYr = edtQualifyYr.getText().toString();
        String tempExperience = edtExperience.getText().toString();
        String tempConsultFee = edtConsultationFee.getText().toString();


        Boolean flag = false;

        if (tempFName.trim().equals("") || tempLName.trim().equals("") || tempUName.trim().equals("") || tempUEmail.trim().equals("") || tempPass.trim().equals("") ||
                tempConfPass.trim().equals("") || tempPhoneNo.trim().equals("") || strSpecilization.equals("Specilization") || strProfession.equals("Profession") || tempConsultFee.trim().equals("")) {

            if (tempFName.trim().equals("") || tempFName == "" || tempFName == null) {
                flag = false;
                layoutFName.setError("First name should not be blank");
                //layoutFName.setError("");
            } else {
                flag = true;
                layoutFName.setError(null);
            }

            if (tempLName.trim().equals("") || tempLName == "" || tempLName == null) {
                flag = false;
                layoutLName.setError("Last name should not be blank");
                //layoutLName.setError("");
            } else {
                flag = true;
                layoutLName.setError(null);
            }

            if (tempUName.trim().equals("") || tempUName == "" || tempUName == null) {
                flag = false;
                layoutUserName.setError("User name should not be blank");
                //layoutUserName.setError("");
            } else {
                flag = true;
                layoutUserName.setError(null);
            }


            if (tempUEmail.trim().equals("") || tempUEmail == "" || tempUEmail == null) {
                flag = false;
                layoutUserEmail.setError("Email should not be blank");
                //layoutUserEmail.setError("");
            } else {
                flag = true;
                layoutUserEmail.setError(null);
            }
            if (!Utilities.emailValidator(tempUEmail) && tempUEmail.length() > 0) {
                flag = false;
                layoutUserEmail.setError("Email id is not valid");
            } else {
                flag = true;
                layoutUserEmail.setError(null);
            }

            if (tempPass.trim().equals("") || tempPass == "" || tempPass == null || tempPass.length() < 8) {
                flag = false;
                layoutPassword.setError("Password should be minimum 8 character");
                //layoutPassword.setError("");
            } else {
                flag = true;
                layoutPassword.setError(null);
            }

            if (tempConfPass.trim().equals("") || tempConfPass == "" || tempConfPass == null || tempConfPass.length() < 8) {
                flag = false;
                layoutConfPass.setError("Confirm Password should be minimum 8 character");
                //layoutConfPass.setError("");
            } else {
                flag = true;
                layoutConfPass.setError(null);
            }

            if ((tempConfPass.trim().equals(tempPass) || tempConfPass != tempPass) && tempConfPass.length() > 0) {
                flag = false;
                layoutConfPass.setError("Password & Confirm Password is not match");
            } else {
                flag = true;
                layoutConfPass.setError(null);
            }

            if (tempPhoneNo.trim().equals("") || tempPhoneNo == "" || tempPhoneNo == null || tempPhoneNo.length() < 10) {
                flag = false;
                layoutPhoneNo.setError("Phone no. should be 10 digits");
            } else {
                flag = true;
                layoutPhoneNo.setError(null);
            }

            if (strProfession.equals("Profession")) {
                flag = false;
                Toast.makeText(RegisterAsProfessionalActivity.this,"Please select profession.",Toast.LENGTH_SHORT).show();
            } else {
                flag = true;
                layoutPhoneNo.setError(null);
            }


            if (tempQualifyYr.trim().equals("") || tempQualifyYr == "" || tempQualifyYr == null || tempQualifyYr.length() < 4) {
                flag = false;
                layoutQualifyYr.setError("Please enter qualifiy year (YYYY).");
            } else {
                flag = true;
                layoutQualifyYr.setError(null);
            }

            if (tempExperience.trim().equals("") || tempExperience == "" || tempExperience == null || tempExperience.length() < 0) {
                flag = false;
                layoutExperience.setError("Please enter experience.");
            } else {
                flag = true;
                layoutExperience.setError(null);
            }

            if (strSpecilization.equals("Specilization")) {
                flag = false;
                Toast.makeText(RegisterAsProfessionalActivity.this,"Please select specilization.",Toast.LENGTH_SHORT).show();
            } else {
                flag = true;
            }

            if (tempConsultFee.trim().equals("") || tempConsultFee == "" || tempConsultFee == null || tempConsultFee.length() < 0) {
                flag = false;
                layoutConsultationFee.setError("Please enter consultation fee.");
            } else {
                flag = true;
                layoutConsultationFee.setError(null);
            }

        } else if(!chkTermMsg.isChecked())
        {
            Toast.makeText(getApplicationContext(), "Please accept term and condition! ", Toast.LENGTH_SHORT).show();
        }
        else

        {
            progress.show();
            SinUpProfessional(tempFName, tempLName, tempUName, tempUEmail, tempPass, tempConfPass, tempPhoneNo,strProfessionID,"2",tempQualifyYr,tempConsultFee,tempExperience,"0","1");
        }

    }


    public void SinUpProfessional(String tempFName, String tempLName, String tempUName, String tempUEmail, String tempPass, String confPass, String tempPhoneNo,
                                  String tempstrProfessionID, String qualification, String tempQualifyYr, String tempConsultFee,
                                  String tempExperience, String packageID, String termCondition) {
        ApiService mApiService = Singleton.getInstance().getApi();
        mApiService.ProfRegister(/*Singleton.getInstance().getEncryptedUID(getApplicationContext())*/"VetmH3NVOD4wLpMANbuZ0hJlJpGtBkd1p3xoMK6QVFQ=", tempUName, tempPass, confPass,
                tempFName, tempLName, tempUEmail, tempPhoneNo, tempstrProfessionID, qualification, tempQualifyYr, tempConsultFee, tempExperience, packageID, termCondition).
                enqueue(new Callback<AbstractResponseList<ResponseMeta, ProfRegisterData>>() {
                    @Override
                    public void onResponse(Response<AbstractResponseList<ResponseMeta, ProfRegisterData>> response) {
                        ResponseMeta responseMeta = response.body().getResponseMeta();
                        progress.dismiss();
                        int code = responseMeta.getCode();

                        if (code == 407) {
                            //Toast.makeText(RegisterAsProfessionalActivity.this, response.body().getData().get(0).getMessage(), Toast.LENGTH_SHORT).show();

                            startActivity(new Intent(RegisterAsProfessionalActivity.this, Dashboard.class));
                            finish();

                        } else {
                           // Toast.makeText(RegisterAsProfessionalActivity.this, response.body().getData().get(0).getError().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        progress.dismiss();
                        Log.d("getLogin", "error = " + t.getMessage());
                    }
                });
    }
}

