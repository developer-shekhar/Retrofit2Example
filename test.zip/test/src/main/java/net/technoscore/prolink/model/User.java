package net.technoscore.prolink.model;


import com.google.gson.annotations.SerializedName;
import net.technoscore.prolink.Singleton;

/**
 * Created by suntec on 18/01/16.
 */
public class User {

    @SerializedName("id")
    private int userId;


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
 public String userIdMd5(){

     return Singleton.getInstance().getMD5(Integer.toString(this.userId));
 }

}
