package net.technoscore.prolink.model.queries;

/**
 * Created by Vijay on 3/2/2016.
 */
public class Query_data
{
    private String query_subject;

    private String is_comment;

    private String is_interested;

    private String query_message;

    private String query_file;

    private String query_id;

    public String getQuery_subject ()
{
    return query_subject;
}

    public void setQuery_subject (String query_subject)
    {
        this.query_subject = query_subject;
    }

    public String getIs_comment ()
{
    return is_comment;
}

    public void setIs_comment (String is_comment)
    {
        this.is_comment = is_comment;
    }

    public String getIs_interested ()
{
    return is_interested;
}

    public void setIs_interested (String is_interested)
    {
        this.is_interested = is_interested;
    }

    public String getQuery_message ()
{
    return query_message;
}

    public void setQuery_message (String query_message)
    {
        this.query_message = query_message;
    }

    public String getQuery_file ()
    {
        return query_file;
    }

    public void setQuery_file (String query_file)
    {
        this.query_file = query_file;
    }

    public String getQuery_id ()
    {
        return query_id;
    }

    public void setQuery_id (String query_id)
    {
        this.query_id = query_id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [query_subject = "+query_subject+", is_comment = "+is_comment+", is_interested = "+is_interested+", query_message = "+query_message+", query_file = "+query_file+", query_id = "+query_id+"]";
    }
}