
package net.technoscore.prolink.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ErrorResponse {

    @SerializedName("error_field")
    @Expose
    private String errorField;
    @SerializedName("error")
    @Expose
    private String error;

    /**
     * 
     * @return
     *     The errorField
     */
    public String getErrorField() {
        return errorField;
    }

    /**
     * 
     * @param errorField
     *     The error_field
     */
    public void setErrorField(String errorField) {
        this.errorField = errorField;
    }

    /**
     * 
     * @return
     *     The error
     */
    public String getError() {
        return error;
    }

    /**
     * 
     * @param error
     *     The error
     */
    public void setError(String error) {
        this.error = error;
    }

}
