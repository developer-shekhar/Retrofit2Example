package net.technoscore.prolink;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Created by Vijay on 3/1/2016.
 */
public class OTPVerificationActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edtKey;
    private Button btnKeySearch;
    ActionBar mActionBar;
    View mCustomView;
    LayoutInflater mInflater;
    TextInputLayout layout_key;
    Dialog progress;
    TextView btnSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_verification_activity);
        setupactionbar("Otp Verification");
        init();
    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init() {

        layout_key = (TextInputLayout) findViewById(R.id.layout_key);
        edtKey = (EditText) findViewById(R.id.edtKey);
        btnKeySearch = (Button) findViewById(R.id.btnKeySearch);
        btnKeySearch.setOnClickListener(this);

        btnSkip= (TextView) findViewById(R.id.btnSkip);
        btnSkip.setOnClickListener(this);



        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnKeySearch:

                submitOtp();
                break;
            case R.id.btnSkip:
                startActivity(new Intent(this, LoginActivity.class));
                finish            ();
        }

    }

    public void submitOtp() {
        String tempOtp = edtKey.getText().toString();
        if (tempOtp.trim().equals("") || tempOtp == "" || tempOtp == null)
        {
            layout_key.setError("Enter OTP number");
        }else
        {
            layout_key.setError(null);
        }

        if (tempOtp.length()>4)
        {
            layout_key.setError("Enter valid OTP number");
        }else
        {
            layout_key.setError(null);
        }
    }
}