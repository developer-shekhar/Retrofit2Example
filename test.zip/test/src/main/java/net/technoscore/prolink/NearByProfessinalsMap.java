package net.technoscore.prolink;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.FindNearMeResultList;
import net.technoscore.prolink.model.ResponseMetaSearchNear;
import net.technoscore.prolink.model.UserData;
import net.technoscore.prolink.model.filtermodel.Locationhelper;
import net.technoscore.prolink.util.GlobalVars;
import net.technoscore.prolink.util.SharedPrefHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Vijay on 2/25/2016.
 */
public class NearByProfessinalsMap extends AppCompatActivity {

    Spinner spnProfessional, spnDistance;
    AutoCompleteTextView edtLocation;
    private ArrayAdapter<String> LocationAdapter;
    private ArrayAdapter<String> mArrayAdapter;
    private GoogleMap googleMap;
    Dialog progress;
    SharedPrefHelper sph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.near_by_list_map);
        setupactionbar("Professionals");
        init();

    }

    public void init() {
        spnProfessional = (Spinner) findViewById(R.id.spnProfessional);
        spnDistance = (Spinner) findViewById(R.id.spnDistance);
        edtLocation = (AutoCompleteTextView) findViewById(R.id.edtLocation);
        sph = new SharedPrefHelper(this);


        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));


        try {
            if (googleMap == null) {
                googleMap = ((MapFragment) getFragmentManager().
                        findFragmentById(R.id.map)).getMap();
            }
            googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            googleMap.setMyLocationEnabled(true);

            googleMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {

                @Override
                public void onMyLocationChange(Location arg0) {
                    // TODO Auto-generated method stub
                    // googleMap.addMarker(new MarkerOptions().position(new LatLng(arg0.getLatitude(), arg0.getLongitude())).title("It's Me!"));
                    MarkerOptions marker = new MarkerOptions().position(new LatLng(arg0.getLatitude(), arg0.getLongitude())).title("It's Me!");
                    marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.me));
                    googleMap.addMarker(marker);
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
        }


        sph = new SharedPrefHelper(this);

        Gson gsn = new Gson();
        String js = sph.getString("USERDATA", "");
        UserData objUserData = gsn.fromJson(js, UserData.class);
        String token = objUserData.getToken();
        String UserID = objUserData.getUserId();

        ApiService mApiService = Singleton.getInstance().getApi();
        progress.show();
        mApiService.findNearMe(token, UserID, GlobalVars.lattitude + "", GlobalVars.longitude + "", "100", "", "", "", "", "")
                .enqueue(new Callback<AbstractResponseList<ResponseMetaSearchNear,
                        FindNearMeResultList>>() {

                    @Override
                    public void onResponse(Response<AbstractResponseList<ResponseMetaSearchNear,
                            FindNearMeResultList>> response) {
                        ResponseMetaSearchNear metaData = response.body().getResponseMeta();
                        List<FindNearMeResultList> searchResult = response.body().getData();

                        for (int i = 0; i < searchResult.size(); i++) {
                            Marker TP = googleMap.addMarker(new MarkerOptions().
                                    position(new LatLng(Double.parseDouble(searchResult.get(i).getLatitude()), Double.parseDouble(searchResult.get(i).getLongitude()))).title(searchResult.get(i).getFirstName().toString()));
                           googleMap.moveCamera( CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(searchResult.get(i).getLatitude()), Double.parseDouble(searchResult.get(i).getLongitude())), 7.0f) );
                        }
                        Log.d("NearByProfessinals", "onResponse = " + response.code());
                        progress.dismiss();

                    }

                    @Override
                    public void onFailure(Throwable t) {

                        Log.d("NearByProfessinals", "onFailure = " + t.getMessage());
                        progress.dismiss();
                    }
                });


    }




    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
