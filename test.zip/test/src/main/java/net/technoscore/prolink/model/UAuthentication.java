package net.technoscore.prolink.model;


import com.google.gson.annotations.SerializedName;


/**
 * Created by suntec on 18/01/16.
 */
public class UAuthentication {

    @SerializedName("token")
    private String token;


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
