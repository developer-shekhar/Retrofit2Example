
package net.technoscore.prolink.model.filtermodel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class DataSpecialist {

    @SerializedName("id")
    private String id;
    @SerializedName("label")
    private String label;
    @SerializedName("parent_id")
    private String parentId;

    /**
     * 
     * @return
     *     The id
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 
     * @return
     *     The label
     */
    public String getLabel() {
        return label;
    }

    /**
     * 
     * @param label
     *     The label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * 
     * @return
     *     The parentId
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * 
     * @param parentId
     *     The parent_id
     */
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

}
