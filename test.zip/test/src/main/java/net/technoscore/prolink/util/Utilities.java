package net.technoscore.prolink.util;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import net.technoscore.prolink.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by suntec on 29/2/16.
 */
public class Utilities {

    public static void ShareApp(Context context){

        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        //sharingIntent.setData(Uri.parse("market://details?id=com.storesay.customerapp"));
        //Uri uri = new Uri.Builder("market://details?id=com.storesay.customerapp");
        // String shareBody = "Hey!! Downlaod the Storesay Customer App from Play Store to get exciting offer and deals on Purchase of Home Appliances..\n\n "+ Uri.parse("https://play.google.com/store/apps/details?id=com.storesay.customerapp") + "";

        // String DealDescription = mDealsOfferList.get(id).getDealDescription();
        String Link = "https://play.google.com/apps/testing/com.storesay.customerapp";
        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        String shareBody =	"Hey" ;

        StringBuilder sbuilder = new StringBuilder();

        sbuilder.append("Hey, check out StoreSay android app ");
        sbuilder.append("http://play.google.com/store/apps/details?id=" + context.getPackageName());

        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, ("Prolink"));
        sharingIntent.putExtra(Intent.EXTRA_TEXT, sbuilder.toString());
        context.startActivity(Intent.createChooser(sharingIntent, "Share via"));

    }



    public static void RateApp(Context context) {
        // TODO Auto-generated method stub

        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        // To count with Play market backstack, After pressing back button,
        // to taken back to our application, we need to add following flags to intent.
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            context.startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            context.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())));
        }

    }
    public static boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static String getVersionNumber(Context context) {
        int versionCode = 0;
        String name="1.0";
        try {
            versionCode = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), 0).versionCode;
            name=context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return name;
    }
    public static boolean hasActiveInternetConnection(Context context) {
        if (isNetworkAvailable(context)) {
            return true;
        } else {
            //Log.d(LOG_TAG, "No network available!");
        }
        return false;
    }
    public static void showAlert(Context context) {

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        dialog.setContentView(R.layout.erroralert);
        //dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        Button done=(Button)dialog.findViewById(R.id.button1);
        dialog.setTitle("");
        done.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                dialog.cancel();
            }
        });
        dialog.show();
    }
    public static String getDate() {
        String DATE_FORMAT_NOW = "dd/MM/yyyy";
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
        return sdf.format(cal.getTime());

    }

    public static String getDateFromInteger(String val) {
        long yourmilliseconds = Long.parseLong(val);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Date resultdate = new Date(yourmilliseconds);

        return (sdf.format(resultdate));
    }

    public static String calculateElapsedTime(String purchasedTime,
                                              String borrowedDuration,String currentTime) {

        String result = "0";
        // Calendar cal = Calendar.getInstance();
        long current = Long.parseLong(currentTime) ;

        long purchasedUpto = Long.parseLong(purchasedTime+"000")+ Long.parseLong(borrowedDuration);

        if (current <=purchasedUpto) {
            result = String.valueOf((int) (((purchasedUpto - current) / (1000*60*60))));
        }else{
            result = String.valueOf("-" +(int) (((current-purchasedUpto ) / (1000*60*60))));
        }

        return result;
    }

    public String getHours(Long purchasedUpto,Long current) {
        String result="0";
        long difference=purchasedUpto - current;

        return result;
    }
    public static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

    public static String writeBytesToFile( InputStream in) throws IOException {
        byte[] ba1 = new byte[1024];
        int baLength;
        File file = new File(Environment.getExternalStorageDirectory().getPath(), "/.temp.abs");
        if(file.exists()) {
            file.delete();
        }
        FileOutputStream fos1 = new FileOutputStream( file);
        while ((baLength = in.read(ba1)) != -1) {
            fos1.write(ba1, 0, baLength);
        }
        fos1.flush();
        fos1.close();
        in.close();
        return "true";
    }

    public static Bitmap getCircularBitmapWithWhiteBorder(Bitmap bitmap, int borderWidth) {
        if (bitmap == null || bitmap.isRecycled()) {
            return null;
        }

        final int width = bitmap.getWidth() + borderWidth;
        final int height = bitmap.getHeight() + borderWidth;

        Bitmap canvasBitmap = Bitmap.createBitmap(width, height,
                Bitmap.Config.ARGB_8888);
        BitmapShader shader = new BitmapShader(bitmap, Shader.TileMode.CLAMP,
                Shader.TileMode.CLAMP);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(shader);

        Canvas canvas = new Canvas(canvasBitmap);
        float radius = width > height ? ((float) height) / 2f
                : ((float) width) / 2f;
        canvas.drawCircle(width / 2, height / 2, radius, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);

        paint.setColor(Color.parseColor("#FFCF1A"));
        paint.setStrokeWidth(borderWidth);
        canvas.drawCircle(width / 2, height / 2, radius - borderWidth / 2,
                paint);
        return canvasBitmap;
    }
    private static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager)context. getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }
}


