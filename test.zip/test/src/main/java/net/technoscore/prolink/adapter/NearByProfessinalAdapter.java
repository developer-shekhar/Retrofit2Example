package net.technoscore.prolink.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import net.technoscore.prolink.PostAppointmentActivity;
import net.technoscore.prolink.R;
import net.technoscore.prolink.model.FindNearMeResultList;

import java.util.List;

/**
 * Created by mac3 on 01/03/16.
 */
public class NearByProfessinalAdapter extends RecyclerView.Adapter<NearByProfessinalAdapter.CustomViewHolder>  {

    private List<FindNearMeResultList> nearMeResultLists;
    private Context mContext;

    public NearByProfessinalAdapter(Context context, List<FindNearMeResultList> nearMeResultLists) {
        this.nearMeResultLists = nearMeResultLists;
        this.mContext = context;
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_of_professinal_profile_list, null);

        CustomViewHolder viewHolder = new CustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CustomViewHolder customViewHolder, int i) {

        FindNearMeResultList nearMeResult = nearMeResultLists.get(i);


        if (nearMeResult != null) {

            Picasso.with(mContext).load(nearMeResult.getProfileImage()).into(customViewHolder.profile_img);

            customViewHolder.profile_name.setText( getSafeSubstring(nearMeResult.getFirstName()+" "+nearMeResult.getLastName(),15));
            customViewHolder.profile_specilazation.setText("CA");
            customViewHolder.pr_distance.setText(nearMeResult.getDistance() + "\nkms.");
            customViewHolder.pr_yrs.setText(nearMeResult.getExperience()+"\nyrs");



            customViewHolder.button_for_oppoitment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                  //  Toast.makeText(mContext,"Fix Meeting", Toast.LENGTH_SHORT).show();
                    Intent intent= new Intent(mContext, PostAppointmentActivity.class);
                    mContext.startActivity(intent);
                }
            });

            customViewHolder.button_bookmark.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(mContext,"BookMark", Toast.LENGTH_SHORT).show();
                }
            });

            customViewHolder.button_view_mode_details.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(mContext,"Details", Toast.LENGTH_SHORT).show();
                }
            });

        }


    }


    public String getSafeSubstring(String s, int maxLength){
        if(!TextUtils.isEmpty(s)){
            if(s.length() >= maxLength){
                return s.substring(0, maxLength)+"...";
            }
        }
        return s;
    }

    @Override
    public int getItemCount() {
        return (null != nearMeResultLists ? nearMeResultLists.size() : 0);
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {


        protected ImageView profile_img;

        protected TextView profile_name;
        protected TextView profile_specilazation;
        protected TextView pr_distance;
        protected TextView pr_yrs;
        protected Button button_for_oppoitment;
        protected Button button_bookmark;
        protected Button button_view_mode_details;
        protected TextView fav_icon;




        public CustomViewHolder(View view) {
            super(view);

            this.profile_img = (ImageView) view.findViewById(R.id.profile_img);
            this.profile_name = (TextView) view.findViewById(R.id.profile_name);
            this.profile_specilazation = (TextView) view.findViewById(R.id.profile_specilazation);
            this.profile_specilazation = (TextView) view.findViewById(R.id.profile_specilazation);
            this.pr_distance = (TextView) view.findViewById(R.id.pr_distance);
            this.pr_yrs = (TextView) view.findViewById(R.id.pr_yrs);

            this.button_for_oppoitment = (Button) view.findViewById(R.id.button_for_oppoitment);
            this.button_bookmark = (Button) view.findViewById(R.id.button_bookmark);
            this.button_view_mode_details = (Button) view.findViewById(R.id.button_view_mode_details);
            this.fav_icon = (TextView) view.findViewById(R.id.fav_icon);




        }
    }



}
