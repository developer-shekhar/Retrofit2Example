package net.technoscore.prolink.model;

/**
 * Created by suntec on 2/3/16.
 */
public class ProfRegisterData {

    private String message;
    private String error_field;

    private String error;

    public String getError_field ()
    {
        return error_field;
    }

    public void setError_field (String error_field)
    {
        this.error_field = error_field;
    }

    public String getError ()
    {
        return error;
    }

    public void setError (String error)
    {
        this.error = error;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [error_field = "+error_field+", error = "+error+"]";
    }
    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }


}
