package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by suntec on 29/2/16.
 */
public class ClientRegisterData {
   /* private String message;
    private String error_field;

    private String error;

    public String getError_field ()
    {
        return error_field;
    }

    public void setError_field (String error_field)
    {
        this.error_field = error_field;
    }

    public String getError ()
    {
        return error;
    }

    public void setError (String error)
    {
        this.error = error;
    }

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    @Override
    public String toString()
    {
        return "ClientRegisterData [message = "+message+"]";
    }*/

    @SerializedName("message")
    private String message;

    /**
     *
     * @return
     *     The message
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message
     *     The message
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
