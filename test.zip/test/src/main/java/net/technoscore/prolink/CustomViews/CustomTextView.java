package net.technoscore.prolink.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;

import net.technoscore.prolink.R;


public class CustomTextView extends TextView {

    public CustomTextView(Context context) {
        super(context);
        FontUtils.setFontFace(context, this, "NORMAL");
    }

    public CustomTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        if (!isInEditMode()) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView, 0, 0);
            String fontName = a.getString(R.styleable.CustomTextView_customFont);
            a.recycle();

            if (fontName != null)
                FontUtils.setFontFace(context, this, fontName);
            else FontUtils.setFontFace(context, this, "NORMAL");
        }
    }
}