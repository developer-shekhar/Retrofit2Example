package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by suntec on 18/01/16.
 */

public  class AbstractResponseList<Tm, Td> {



    // used for error handling
    @SerializedName("response_meta")
    private Tm responseMeta;



    @SerializedName("data")
    private List<Td> data;


    public Tm getResponseMeta() {

        return responseMeta;
    }

    public void setResponseMeta(Tm responseMeta) {
        this.responseMeta = responseMeta;
    }


    public List<Td> getData() {
        return data;
    }

    public void setData(List<Td> data) {
        this.data = data;
    }
}