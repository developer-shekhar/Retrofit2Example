package net.technoscore.prolink.util;

import net.technoscore.prolink.model.filtermodel.CheckboxListHelper;

import java.util.ArrayList;

/**
 * Created by suntec on 1/3/16.
 */
public  class GlobalVars {
   public static String  Location="";
   public  static  int ProfType=0;
   public static ArrayList<CheckboxListHelper> SelectedType= new ArrayList<>();

   public static ArrayList<CheckboxListHelper> SelectedSpecialization= new ArrayList<>();

   public static double lattitude=28.5514034;
   public static double longitude=77.2517671;

}
