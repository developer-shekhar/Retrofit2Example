package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by mac3 on 01/03/16.
 */
public class FindNearMeResultList {


    @SerializedName("id")
    private int userId;


    @SerializedName("first_name")
    private String firstName;


    @SerializedName("last_name")
    private String lastName;

    @SerializedName("professional_type")
    private String professionalType;

    @SerializedName("experience")
    private String experience;

    @SerializedName("address")
    private String address;

     @SerializedName("profile_image")
    private String profileImage;


    @SerializedName("distance")
    private String distance;


    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @SerializedName("latitude")
    private String latitude;


    @SerializedName("longitude")
    private String longitude;





    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getProfessionalType() {
        return professionalType;
    }

    public void setProfessionalType(String professionalType) {
        this.professionalType = professionalType;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getDistance() {
        return String.format("%.2f", Double.parseDouble(distance));
       // return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    // @SerializedName("specialization")
   // private int specialization;







}
