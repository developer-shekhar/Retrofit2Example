package net.technoscore.prolink.model;


import com.google.gson.annotations.SerializedName;


/**
 * Created by suntec on 18/01/16.
 */
public class TreasurePlan {

    @SerializedName("id")
    private String treasureId;

@SerializedName("city_name")
    private String cityName;

@SerializedName("end_date")
    private String endDate;


@SerializedName("treasure_status")
    private String treasureStatus;

@SerializedName("time_left")
    private String timeLeft;


    public String getTimeLeft() {
        return timeLeft;
    }

    public void setTimeLeft(String timeLeft) {
        this.timeLeft = timeLeft;
    }

    public String getTreasureStatus() {
        return treasureStatus;
    }

    public void setTreasureStatus(String treasureStatus) {
        this.treasureStatus = treasureStatus;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getTreasureId() {
        return treasureId;
    }

    public void setTreasureId(String treasureId) {
        this.treasureId = treasureId;
    }
}
