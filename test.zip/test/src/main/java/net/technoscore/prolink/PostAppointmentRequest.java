package net.technoscore.prolink;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;

/**
 * Created by Vijay on 2/25/2016.
 */
public class PostAppointmentRequest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_appointment_request);

    }

}
