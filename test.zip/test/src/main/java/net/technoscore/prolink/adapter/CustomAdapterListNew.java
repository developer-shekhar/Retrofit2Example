package net.technoscore.prolink.adapter;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;


import net.technoscore.prolink.R;
import net.technoscore.prolink.model.filtermodel.DataProfessioanlType;

public class CustomAdapterListNew extends BaseAdapter {

	public List<DataProfessioanlType> _data;
	Context _c;

	int itemp = 0;
	ArrayList<DataProfessioanlType> checkedSelection;// = new ArrayList<String>();
	public int checkedCount = 0;
	public boolean isActionModeShowing;
	private SparseBooleanArray mSelectedItemsIds;
	ViewHolderItem viewHolder;
	LayoutInflater inflator;
	Activity activity;
	int userid;
	boolean[] checkBoxState;
	public android.view.ActionMode actionMode;

	Dialog dialog;
	LayoutInflater inflater;
	View view;

	public CustomAdapterListNew(List data, Context c, Activity ac) {
		mSelectedItemsIds = new SparseBooleanArray();
		_data = data;
		_c = c;
		viewHolder = new ViewHolderItem();
		checkedSelection = new ArrayList<DataProfessioanlType>();
		checkBoxState = new boolean[_data.size()];
        this.activity=ac;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return _data.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return _data.get(position);
	}

	public void removeSelection() {
		checkBoxState = new boolean[_data.size()];
		// mSelectedItemsIds = new SparseBooleanArray();
		notifyDataSetChanged();
	}

	public SparseBooleanArray getSelectedIds() {
		return mSelectedItemsIds;
	}

	public void toggleSelection(int position) {
		selectView(position, !mSelectedItemsIds.get(position));
	}

	public void selectView(int position, boolean value) {
		if (value) {
			mSelectedItemsIds.put(position, value);
		} else {
			mSelectedItemsIds.delete(position);
			notifyDataSetChanged();
		}
	}

	public void deleteItem(int position) {
		_data.remove(position);
		notifyDataSetChanged();
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		// View v = convertView;
		if (convertView == null) {
			viewHolder = new ViewHolderItem();
			LayoutInflater vi = (LayoutInflater) _c
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(R.layout.profession_list_items, null);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolderItem) convertView.getTag();
		}

		viewHolder.textView1 = (TextView) convertView
				.findViewById(R.id.textView1);
		viewHolder.checkBox1 = (CheckBox) convertView
				.findViewById(R.id.checkBox1);

	final	DataProfessioanlType list = (DataProfessioanlType) _data.get(position);
        viewHolder.textView1.setText(list.getType());
        viewHolder.checkBox1
                .setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                                                 boolean isChecked) {
                        if (isChecked) {
                           /* checkBoxState[position] = true;
                            checkedSelection.add(_data.get(position));

                            int getPosition = (Integer) buttonView.getTag();
                            _data.get(getPosition).setSelected(
                                    buttonView.isChecked());*/

                            android.view.ActionMode actionMode1 = actionMode;
                            if (actionMode == null) {
                                actionMode = activity
                                        .startActionMode(new MyActionModeCallBack());

                            } else {

                            }

                        } else {

                            checkedSelection.remove(_data.get(position));
                            checkBoxState[position] = false;

                        }

                        /*

                        Set<ListingHelper> set = new HashSet<ListingHelper>(
                                checkedSelection);
                        int checkedCount = set.size();

                        actionMode.setTitle(checkedCount + " Selected");

                        if (checkedCount == 0) {
                            actionMode.finish();

                        }*/

                    }
                });

		return convertView;
	}



	static class ViewHolderItem {

        TextView textView1;
		CheckBox checkBox1;
	}

    class MyActionModeCallBack implements android.view.ActionMode.Callback {
        @Override
        public boolean onCreateActionMode(android.view.ActionMode mode,
                                          Menu menu) {

            mode.getMenuInflater().inflate(R.menu.dashboard, menu);

            return true;
        }

        @Override
        public boolean onPrepareActionMode(android.view.ActionMode mode,
                                           Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(final android.view.ActionMode mode,
                                           MenuItem item) {

            String OrderId = "";
/*
            for (int i = 0; i < checkedSelection.size(); i++) {
                OrderId += checkedSelection.get(i).getOrderId() + ",";
            }

            final String orderids = OrderId;
            dialog = new Dialog(_c);
            inflater = (LayoutInflater) _c .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dilog_cancel, null, false);*/



            switch (item.getItemId()) {
                case R.id.action_settings:



                    return true;



                default:
                    return false;
            }

        }

        @Override
        public void onDestroyActionMode(android.view.ActionMode mode) {

			/*
			 * for(ListingHelper p:_data) { p.setSelected(false); }
			 * notifyDataSetChanged();
			 */

            /*((SPXMainActivity) activity)
                    .addFragment(new LeadsListingFragment());*/
        }

    }
}