package net.technoscore.prolink.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.Button;

import net.technoscore.prolink.R;

public class CustomButton extends Button {

    public CustomButton(Context context) {
        super(context);
        FontUtils.setFontFace(context, this, "NORMAL");
    }

    public CustomButton(Context context, AttributeSet attrs) {
        super(context, attrs);

        if (!isInEditMode()) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView, 0, 0);
            String fontName = a.getString(R.styleable.CustomTextView_customFont);
            a.recycle();

            if (fontName != null)
                FontUtils.setFontFace(context, this, fontName);
            else FontUtils.setFontFace(context, this, "NORMAL");
        }
    }
}