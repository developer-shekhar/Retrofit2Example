
package net.technoscore.prolink.model;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ResponseLogin {

    @SerializedName("response_meta")

    private ResponseMeta responseMeta;
    @SerializedName("data")

    private List<UserData> data;

    /**
     *
     * @return
     *     The responseMeta
     */
    public ResponseMeta getResponseMeta() {
        return responseMeta;
    }

    /**
     *
     * @param responseMeta
     *     The response_meta
     */
    public void setResponseMeta(ResponseMeta responseMeta) {
        this.responseMeta = responseMeta;
    }

    /**
     *
     * @return
     *     The data
     */
    public List<UserData> getData() {
        return data;
    }

    /**
     *
     * @param data
     *     The data
     */
    public void setData(List<UserData> data) {
        this.data = data;
    }

}
