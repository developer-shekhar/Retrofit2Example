package net.technoscore.prolink;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.plus.Plus;
import com.google.gson.Gson;
import com.linkedin.platform.LISessionManager;
import com.linkedin.platform.errors.LIAuthError;
import com.linkedin.platform.listeners.AuthListener;
import com.linkedin.platform.utils.Scope;


import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.ResponseMeta;
import net.technoscore.prolink.model.UserData;
import net.technoscore.prolink.model.filtermodel.FilterData;
import net.technoscore.prolink.util.SharedPrefHelper;

import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Vijay on 2/19/2016.
 */
public class LoginActivity extends AppCompatActivity implements View.OnClickListener,
        ActivityCompat.OnRequestPermissionsResultCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {


    TextInputLayout layout_edtUsername, layout_edtPassword;

    Button btnLoginAsClient, btnRegister;
    ImageView imgLinkedIn;
    ImageView imgFacebook;
    ImageView imgGoogle;
    CallbackManager callbackManager;
    AccessTokenTracker accessTokenTracker;
    AccessToken accessToken;
    public int mScialCode = 0;
    public static final int FACEBOOK_SELECT = 3;
    public static final int LINKEDIN_SELECT = 1;
    public static final int GOOGLE_SELECT = 2;
    ActionBar mActionBar;
    View mCustomView;
    LayoutInflater mInflater;

    /* RequestCode for resolutions to get GET_ACCOUNTS permission on M */
    private static final int RC_PERM_GET_ACCOUNTS = 2;

    /* Keys for persisting instance variables in savedInstanceState */
    private static final String KEY_IS_RESOLVING = "is_resolving";
    private static final String KEY_SHOULD_RESOLVE = "should_resolve";

    private String facebook_id, f_name, m_name, l_name, gender, profile_image, full_name, email_id;

    //********************************
    private static final int RC_SIGN_IN = 0;
    private boolean mIsResolving = false;

    /* Should we automatically resolve ConnectionResults when possible? */
    private boolean mShouldResolve = false;
    // Google client to communicate with Google

    private boolean mIntentInProgress;
    private boolean signedInUser;
    private ConnectionResult mConnectionResult;
    private ImageView image;
    private GoogleApiClient mGoogleApiClient;
    private ProgressDialog mProgressDialog;
    private GoogleApiClient client;
    private EditText edtUsername, edtPassword;
    private String strUsername, strPassword;
    private ApiService mApiService;

    SharedPrefHelper sph;

    Dialog progress;

    TextView forgot_password;

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        mGoogleApiClient.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "ProlinkFields Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.start(mGoogleApiClient, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "ProlinkFields Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.end(mGoogleApiClient, viewAction);
        mGoogleApiClient.disconnect();
    }

    public enum LoginType {
        LOGIN_AS_CLIENT, LOGIN_AS_PROFESSIONAL
    }

    public static LoginType enumLoginType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sign_in_as_client);

        if (savedInstanceState != null) {
            mIsResolving = savedInstanceState.getBoolean(KEY_IS_RESOLVING);
            mShouldResolve = savedInstanceState.getBoolean(KEY_SHOULD_RESOLVE);
        }
        init();


        FacebookSdk.sdkInitialize(LoginActivity.this);
        callbackManager = CallbackManager.Factory.create();

        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code
                        Profile profile = Profile.getCurrentProfile();
                        if (profile != null) {
                            facebook_id = profile.getId();
                            f_name = profile.getFirstName();
                            m_name = profile.getMiddleName();
                            l_name = profile.getLastName();
                            full_name = profile.getName();
                            profile_image = profile.getProfilePictureUri(400, 400).toString();
                        }
                        // Toast.makeText(getApplicationContext(), "Hello " + full_name, Toast.LENGTH_SHORT).show();
                        Log.d("Facebook", "Login succesfully");


                        String accessToken = loginResult.getAccessToken().getToken();
                        Log.i("accessToken", accessToken);

                        GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {

                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                Log.i("LoginActivity", response.toString());
                                // Get facebook data from login
                                Bundle bFacebookData = getFacebookData(object);
                                //    Toast.makeText(getApplicationContext(), "Hello " + bFacebookData.getString("email"), Toast.LENGTH_SHORT).show();
                            }
                        });

                        Bundle parameters = new Bundle();
                        parameters.putString("fields", "id, first_name, last_name, email,gender, birthday, location"); // Parámetros que pedimos a facebook
                        request.setParameters(parameters);
                        request.executeAsync();

                        LoginActivity.this.startActivity(new Intent(LoginActivity.this, RegisterAsProfessionalActivity.class));
                    }

                    @Override
                    public void onCancel() {
                        // App code
                        Log.d("Facebook", "Canceled");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                        Log.d("Facebook", "error");
                    }
                });

        // ATTENTION: This "addApi(AppIndex.API)"was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(Plus.API)
                .addScope(new com.google.android.gms.common.api.Scope(Scopes.PROFILE))
                .addScope(new com.google.android.gms.common.api.Scope(Scopes.EMAIL))
                .addApi(AppIndex.API).build();


        if (enumLoginType == LoginType.LOGIN_AS_CLIENT)
            setupactionbar("Sign in as client");
        else
            setupactionbar("Sign in as professional");
    }


    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init() {
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
        btnLoginAsClient = (Button) findViewById(R.id.btnLoginAsClient);
        btnLoginAsClient.setOnClickListener(this);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);
        layout_edtUsername = (TextInputLayout) findViewById(R.id.layout_edtUsername);
        layout_edtPassword = (TextInputLayout) findViewById(R.id.layout_edtPassword);
        forgot_password = (TextView) findViewById(R.id.forgot_password);
        forgot_password.setOnClickListener(this);
        sph = new SharedPrefHelper(getApplicationContext());
        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        imgLinkedIn = (ImageView) findViewById(R.id.imgLinkedIn);
        imgLinkedIn.setOnClickListener(this);
        imgFacebook = (ImageView) findViewById(R.id.imgFacebook);
        imgFacebook.setOnClickListener(this);
        imgGoogle = (ImageView) findViewById(R.id.imgGoogle);
        imgGoogle.setOnClickListener(this);
        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);
        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
    }

    private void userLogin() {
        mApiService = Singleton.getInstance().getApi();
        progress.show();
        int loginType = 0;
        if (enumLoginType == LoginType.LOGIN_AS_CLIENT)
            loginType = 2;
        else
            loginType = 5;
        mApiService.getLogin(strUsername, strPassword, "2", "" + loginType, "1").enqueue(new Callback<AbstractResponseList<ResponseMeta, UserData>>() {

            @Override
            public void onResponse(Response<AbstractResponseList<ResponseMeta, UserData>> response) {
                ResponseMeta responseMeta = response.body().getResponseMeta();
                Log.d("getLogin", "onResponse = " + response.message() + " body = " + response.body() + " response code = " + responseMeta.getCode());

                if (responseMeta.getCode() == 200) {
                    List<UserData> d = response.body().getData();
                    Gson gson = new Gson();
                    String json = gson.toJson(d.get(0));
                    sph.setString("USERDATA", json);
                    sph.setBoolean("ISLOGIN", true);

                    if (enumLoginType == LoginType.LOGIN_AS_CLIENT) {
                        Intent mIntent = new Intent(LoginActivity.this, FindProfessionActivity.class);
                        mIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(mIntent);
                        finish();
                    } else if (enumLoginType == LoginType.LOGIN_AS_PROFESSIONAL) {
                        Intent mIntent = new Intent(LoginActivity.this, ProfessionalDashboard.class);
                        mIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(mIntent);

                        finish();
                    }

                } else {
                    Toast.makeText(getApplicationContext(), responseMeta.getMessage(), Toast.LENGTH_SHORT).show();
                }
                progress.dismiss();
            }

            @Override
            public void onFailure(Throwable t) {
                Log.d("getLogin", "error = " + t.getMessage());
                progress.dismiss();

            }
        });
    }

    private boolean checkAccountsPermission() {
        final String perm = Manifest.permission.GET_ACCOUNTS;
        int permissionCheck = ContextCompat.checkSelfPermission(this, perm);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            // We have the permission
            return true;
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, perm)) {
            // Need to show permission rationale, display a snackbar and then request
            // the permission again when the snackbar is dismissed.
            ActivityCompat.requestPermissions(LoginActivity.this,
                    new String[]{perm},
                    RC_PERM_GET_ACCOUNTS);
            return false;
        } else {
            // No explanation needed, we can request the permission.
            ActivityCompat.requestPermissions(this,
                    new String[]{perm},
                    RC_PERM_GET_ACCOUNTS);
            return false;
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.imgLinkedIn: {
                mScialCode = 1;
                login_linkedin();

                break;
            }

            case R.id.forgot_password: {

                startActivity(new Intent(this, ForgotPasswordActivity.class));
                break;
            }

            case R.id.imgGoogle: {
                mScialCode = 2;
                //  checkAccountsPermission();
                mGoogleApiClient.connect();
                // Toast.makeText(getApplicationContext(), "Google Connected", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.imgFacebook: {
                mScialCode = 3;
                // Toast.makeText(getApplicationContext(), "Button Pressed", Toast.LENGTH_SHORT).show();
                LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "user_friends", "email"));

                break;
            }
            case R.id.btnLoginAsClient:
                strUsername = edtUsername.getText().toString().trim();
                strPassword = edtPassword.getText().toString().trim();

                if (strUsername.trim().equals("") || strPassword.trim().equals("")) {

                    if (strUsername.equals("") || strUsername == "" || strUsername == null) {
                        layout_edtUsername.setError("User name should not be blank");
                        //layoutFName.setError("");
                    } else {
                        layout_edtUsername.setError(null);
                    }

                    if (strPassword.equals("") || strPassword == "" || strPassword == null) {
                        layout_edtPassword.setError("Password should not be blank");
                        //layoutLName.setError("");
                    } else {
                        layout_edtPassword.setError(null);
                    }
                } else {
                    strUsername = Singleton.getInstance().getMD5(strUsername);//"5d9c68c6c50ed3d02a2fcf54f63993b6";//
                    strPassword = Singleton.getInstance().getMD5(strPassword);//"5d9c68c6c50ed3d02a2fcf54f63993b6";//
                    userLogin();
                }


                    /*if (strUsername.equalsIgnoreCase(""))
                        edtUsername.setError("Please enter User Name");
                    else if (strPassword.equalsIgnoreCase(""))
                        edtPassword.setError("Please enter password");
                    else {
                        strUsername = Singleton.getInstance().getMD5(strUsername);//"5d9c68c6c50ed3d02a2fcf54f63993b6";//
                        strPassword = Singleton.getInstance().getMD5(strPassword);//"5d9c68c6c50ed3d02a2fcf54f63993b6";//
                        userLogin();
                    }*/
                break;

            case R.id.btnRegister: {
                if (enumLoginType == LoginType.LOGIN_AS_CLIENT)
                    startActivity(new Intent(LoginActivity.this, RegisterAsClientActivity.class));
                else
                    startActivity(new Intent(LoginActivity.this, RegisterAsProfessionalActivity.class));
                break;
            }

        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(KEY_IS_RESOLVING, mIsResolving);
        outState.putBoolean(KEY_SHOULD_RESOLVE, mShouldResolve);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
//        Log.d(TAG, "onRequestPermissionsResult:" + requestCode);
        if (requestCode == RC_PERM_GET_ACCOUNTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //  showSignedInUI();
            } else {
                //   Log.d(TAG, "GET_ACCOUNTS Permission Denied.");
            }
        }
    }


    private static Scope buildScope() {
        return Scope.build(Scope.R_BASICPROFILE, Scope.W_SHARE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mScialCode == FACEBOOK_SELECT)
            callbackManager.onActivityResult(requestCode, resultCode, data);
        else if (mScialCode == LINKEDIN_SELECT)
            LISessionManager.getInstance(getApplicationContext()).onActivityResult(this, requestCode, resultCode, data);
        else {
            if (requestCode == RC_SIGN_IN) {
                // If the error resolution was not successful we should not resolve further.
                if (resultCode != RESULT_OK) {
                    mShouldResolve = false;
                }

                mIsResolving = false;
                mGoogleApiClient.connect();
            }
        }
    }


    private Bundle getFacebookData(JSONObject object) {
        Bundle bundle = new Bundle();

        try {
            String id = object.getString("id");

            try {
                URL profile_pic = new URL("https://graph.facebook.com/" + id + "/picture?width=200&height=150");
                Log.i("profile_pic", profile_pic + "");
                bundle.putString("profile_pic", profile_pic.toString());

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return null;
            }

            bundle.putString("idFacebook", id);
            if (object.has("first_name"))
                bundle.putString("first_name", object.getString("first_name"));
            if (object.has("last_name"))
                bundle.putString("last_name", object.getString("last_name"));
            if (object.has("email"))
                bundle.putString("email", object.getString("email"));
            if (object.has("gender"))
                bundle.putString("gender", object.getString("gender"));
            if (object.has("birthday"))
                bundle.putString("birthday", object.getString("birthday"));
            if (object.has("location"))
                bundle.putString("location", object.getJSONObject("location").getString("name"));
            return bundle;
        } catch (Exception e) {
        }
        return bundle;
    }


    public void login_linkedin() {
        LISessionManager.getInstance(getApplicationContext()).init(this, buildScope(), new AuthListener() {
            @Override
            public void onAuthSuccess() {

                Intent mIntent = new Intent(LoginActivity.this, FindProfessionActivity.class);
                startActivity(mIntent);
            }

            @Override
            public void onAuthError(LIAuthError error) {

                //  Toast.makeText(getApplicationContext(), "failed " + error.toString(),    Toast.LENGTH_LONG).show();
            }
        }, true);
    }


    @Override
    public void onConnected(Bundle bundle) {

        //   Toast.makeText(getApplicationContext(), "success" + bundle.getString("name"), Toast.LENGTH_LONG).show();
        mShouldResolve = false;
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        //   Toast.makeText(getApplicationContext(), "Failed" + connectionResult, Toast.LENGTH_LONG).show();

        if (!mIsResolving && mShouldResolve) {
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(this, RC_SIGN_IN);
                    mIsResolving = true;
                } catch (IntentSender.SendIntentException e) {
//                    Log.e(TAG, "Could not resolve ConnectionResult.", e);
                    mIsResolving = false;
                    mGoogleApiClient.connect();
                }
            } else {
                // Could not resolve the connection result, show the user an
                // error dialog.
//                showErrorDialog(connectionResult);
            }
        } else {
            // Show the signed-out UI
//            showSignedOutUI();
        }
    }

    private void showErrorDialog(ConnectionResult connectionResult) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);

        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, RC_SIGN_IN,
                        new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                mShouldResolve = false;
                                // showSignedOutUI();
                            }
                        }).show();
            } else {
                // Log.w(TAG, "Google Play Services Error:" + connectionResult);
                String errorString = apiAvailability.getErrorString(resultCode);
                //  Toast.makeText(this, errorString, Toast.LENGTH_SHORT).show();

                mShouldResolve = false;
                //   showSignedOutUI();
            }
        }
    }
}
