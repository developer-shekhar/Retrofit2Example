package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by suntec on 18/01/16.
 */

public  class AbstractResponse<Tm, Td> {



    // used for error handling
    @SerializedName("response_meta")
    private Tm responseMeta;

    @SerializedName("data")
    private  Td resposeData;


    public Tm getResponseMeta() {

        return responseMeta;
    }

    public void setResponseMeta(Tm responseMeta) {
        this.responseMeta = responseMeta;
    }

    public Td getResposeData() {
        return resposeData;
    }

    public void setResposeData(Td data) {
        this.resposeData = data;
    }

}