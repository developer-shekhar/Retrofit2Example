
package net.technoscore.prolink.model;

        import java.util.ArrayList;
        import java.util.List;
        import com.google.gson.annotations.Expose;
        import com.google.gson.annotations.SerializedName;

public class UserData {

    @SerializedName("token")
    @Expose
    private String token;
    @SerializedName("user_id")

    private String userId;
    @SerializedName("role_id")

    private String roleId;
    @SerializedName("firstname")

    private String firstname;
    @SerializedName("lastname")

    private String lastname;
    @SerializedName("username")

    private String username;
    @SerializedName("email")

    private String email;
    @SerializedName("profile")

    private String profile;
    @SerializedName("profession")

    private String profession;
    @SerializedName("specialization")

    private List<Specialization> specialization = new ArrayList<Specialization>();

    @SerializedName("is_remember")

    private String isRemember;
    @SerializedName("parent_id")

    private String parentId;

    /**
     *
     * @return
     *     The token
     */
    public String getToken() {
        return token;
    }

    /**
     *
     * @param token
     *     The token
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     *
     * @return
     *     The userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     *
     * @param userId
     *     The user_id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     *
     * @return
     *     The roleId
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     *
     * @param roleId
     *     The role_id
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
     *
     * @return
     *     The firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     *
     * @param firstname
     *     The firstname
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     *
     * @return
     *     The lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     *
     * @param lastname
     *     The lastname
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     *
     * @return
     *     The username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     *     The username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     *     The email
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     *     The email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     *     The profile
     */
    public String getProfile() {
        return profile;
    }

    /**
     *
     * @param profile
     *     The profile
     */
    public void setProfile(String profile) {
        this.profile = profile;
    }

    /**
     *
     * @return
     *     The profession
     */
    public String getProfession() {
        return profession;
    }

    /**
     *
     * @param profession
     *     The profession
     */
    public void setProfession(String profession) {
        this.profession = profession;
    }

    /**
     *
     * @return
     *     The specialization
     */
    public List<Specialization> getSpecialization() {
        return specialization;
    }

    /**
     *
     * @param specialization
     *     The specialization
     */
    public void setSpecialization(List<Specialization> specialization) {
        this.specialization = specialization;
    }

    /**
     *
     * @return
     *     The isRemember
     */
    public String getIsRemember() {
        return isRemember;
    }

    /**
     *
     * @param isRemember
     *     The is_remember
     */
    public void setIsRemember(String isRemember) {
        this.isRemember = isRemember;
    }

    /**
     *
     * @return
     *     The parentId
     */
    public String getParentId() {
        return parentId;
    }

    /**
     *
     * @param parentId
     *     The parent_id
     */
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

}
