
package net.technoscore.prolink.model.filtermodel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class DataProfessioanlType {

    @SerializedName("id")
    private String id;

    @SerializedName("type")
    private String type;



    /**
     * 
     * @return
     *     The id
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 
     * @return
     *     The type
     */
    public String getType() {
        return type;
    }

    /**
     * 
     * @param type
     *     The type
     */
    public void setType(String type) {
        this.type = type;
    }

}
