package net.technoscore.prolink.model.queries;

/**
 * Created by Vijay on 3/2/2016.
 */

public class MyQueriesCountModel
{
    private String Total_query;

    private String Total_appointment_count;

    private String Total_answer;

    private String Total_interest;

    private String Total_waiting;

    public String getTotal_query ()
    {
        return Total_query;
    }

    public void setTotal_query (String Total_query)
    {
        this.Total_query = Total_query;
    }

    public String getTotal_appointment_count ()
    {
        return Total_appointment_count;
    }

    public void setTotal_appointment_count (String Total_appointment_count)
    {
        this.Total_appointment_count = Total_appointment_count;
    }

    public String getTotal_answer ()
    {
        return Total_answer;
    }

    public void setTotal_answer (String Total_answer)
    {
        this.Total_answer = Total_answer;
    }

    public String getTotal_interest ()
    {
        return Total_interest;
    }

    public void setTotal_interest (String Total_interest)
    {
        this.Total_interest = Total_interest;
    }

    public String getTotal_waiting ()
    {
        return Total_waiting;
    }

    public void setTotal_waiting (String Total_waiting)
    {
        this.Total_waiting = Total_waiting;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Total_query = "+Total_query+", Total_appointment_count = "+Total_appointment_count+", Total_answer = "+Total_answer+", Total_interest = "+Total_interest+", Total_waiting = "+Total_waiting+"]";
    }
}

