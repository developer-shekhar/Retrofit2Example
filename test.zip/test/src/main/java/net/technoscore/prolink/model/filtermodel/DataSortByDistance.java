
package net.technoscore.prolink.model.filtermodel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataSortByDistance {

    @SerializedName("value")
    private String value;
    @SerializedName("text")
    private String text;

    /**
     * 
     * @return
     *     The value
     */
    public String getValue() {
        return value;
    }

    /**
     * 
     * @param value
     *     The value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * 
     * @return
     *     The text
     */
    public String getText() {
        return text;
    }

    /**
     * 
     * @param text
     *     The text
     */
    public void setText(String text) {
        this.text = text;
    }

}
