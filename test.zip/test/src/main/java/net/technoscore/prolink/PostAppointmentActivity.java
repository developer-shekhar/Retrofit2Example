package net.technoscore.prolink;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.ForgotData;
import net.technoscore.prolink.model.ResponseMeta;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Vijay on 3/1/2016.
 */
public class PostAppointmentActivity extends AppCompatActivity implements View.OnClickListener {


    TextInputLayout layoutEmail;
    Dialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_appointment_request);
        setupactionbar("Fix Appointment");
        init();
    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init() {


        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
    }

    @Override
    public void onClick(View v) {




    }


}