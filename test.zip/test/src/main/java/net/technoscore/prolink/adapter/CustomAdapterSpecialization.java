package net.technoscore.prolink.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import net.technoscore.prolink.R;

import net.technoscore.prolink.model.filtermodel.DataSpecialist;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapterSpecialization extends BaseAdapter {

	public List<DataSpecialist> _data;
	Context _c;

	int itemp = 0;
	ArrayList<DataSpecialist> checkedSelection;// = new ArrayList<String>();
	public int checkedCount = 0;
	public boolean isActionModeShowing;
	private SparseBooleanArray mSelectedItemsIds;
	ViewHolderItem viewHolder;
	LayoutInflater inflator;
	Activity activity;
	int userid;
	boolean[] checkBoxState;
	public android.view.ActionMode actionMode;

	Dialog dialog;
	LayoutInflater inflater;
	View view;

	public CustomAdapterSpecialization(List data, Context c) {
		mSelectedItemsIds = new SparseBooleanArray();
		_data = data;
		_c = c;
		viewHolder = new ViewHolderItem();

		checkedSelection = new ArrayList<DataSpecialist>();

		checkBoxState = new boolean[_data.size()];

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return _data.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return _data.get(position);
	}

	public void removeSelection() {
		checkBoxState = new boolean[_data.size()];
		// mSelectedItemsIds = new SparseBooleanArray();
		notifyDataSetChanged();
	}

	public SparseBooleanArray getSelectedIds() {
		return mSelectedItemsIds;
	}

	public void toggleSelection(int position) {
		selectView(position, !mSelectedItemsIds.get(position));
	}

	public void selectView(int position, boolean value) {
		if (value) {
			mSelectedItemsIds.put(position, value);
		} else {
			mSelectedItemsIds.delete(position);
			notifyDataSetChanged();
		}
	}

	public void deleteItem(int position) {
		_data.remove(position);
		notifyDataSetChanged();
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		// View v = convertView;
		if (convertView == null) {
			viewHolder = new ViewHolderItem();
			LayoutInflater vi = (LayoutInflater) _c
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(R.layout.profession_list_items, null);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolderItem) convertView.getTag();
		}

		viewHolder.textView1 = (TextView) convertView
				.findViewById(R.id.textView1);
		viewHolder.checkBox1 = (CheckBox) convertView
				.findViewById(R.id.checkBox1);

		DataSpecialist list = (DataSpecialist) _data.get(position);
        viewHolder.textView1.setText(list.getLabel());


		return convertView;
	}



	static class ViewHolderItem {

		TextView textView1;
		CheckBox checkBox1;
	}


}