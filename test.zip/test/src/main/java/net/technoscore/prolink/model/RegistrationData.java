package net.technoscore.prolink.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by mac3 on 04/03/16.
 */
public class RegistrationData {





}
