package net.technoscore.prolink;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import net.technoscore.prolink.model.UserData;
import net.technoscore.prolink.util.GlobalVars;
import net.technoscore.prolink.util.SharedPrefHelper;

import java.util.List;
import java.util.Locale;

/**
 * Created by Vijay on 2/19/2016.
 */
public class FindProfessionActivity extends AppCompatActivity implements View.OnClickListener, LocationListener {

    Button fin_pr_search_button, fin_pr_search_button_find_near_me;
    SharedPrefHelper sph;
    TextView txtUserName, find_pr_type, txtSelectedType, txtSpecilization, txtLocation, txtAutoLocation;

    RelativeLayout relType, relLocation, relSpecialization;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_find_professional);
        setupactionbar("Find Professionals");
        init();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this);
        }
    }

    public String GetAddress(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        String city = "", state = "", address = "";
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            Log.d("Addrss", addresses + "");

            address = addresses.get(0).getAddressLine(0) +" "+ addresses.get(0).getAddressLine(1);
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            String zip = addresses.get(0).getPostalCode();
            String country = addresses.get(0).getCountryName();
        } catch (Exception e) {

        }
        return address+" " +city+" "+ state;
    }

    @Override
    public void onLocationChanged(Location location) {

        String msg = "New Latitude: " + location.getLatitude()
                + "New Longitude: " + location.getLongitude();

        String address = GetAddress(location.getLatitude(), location.getLongitude());
        if(!address.equalsIgnoreCase("")) {
            txtAutoLocation.setText(address);
            txtLocation.setText(address);
        }
        //Toast.makeText(getBaseContext(), msg +" "+ address, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onProviderDisabled(String provider) {

        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        if (GlobalVars.SelectedType.size() > 0) {

            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < GlobalVars.SelectedType.size(); i++) {
                sb.append(GlobalVars.SelectedType.get(i).getName());

                sb.append(", ");
            }
            // StringUtils.stripEnd(names, ",");
            txtSelectedType.setText(sb.toString().replaceAll(",([^,]*)$", "$1"));
        }

        if (GlobalVars.SelectedSpecialization.size() > 0) {

            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < GlobalVars.SelectedSpecialization.size(); i++) {
                sb.append(GlobalVars.SelectedSpecialization.get(i).getName());
                sb.append(", ");
            }
            // StringUtils.stripEnd(names, ",");
            txtSpecilization.setText(sb.toString().replaceAll(",([^,]*)$", "$1"));
        }
        if (!GlobalVars.Location.equalsIgnoreCase("")) {
            txtLocation.setText(GlobalVars.Location);
        }
    }


    public void init() {
        fin_pr_search_button = (Button) findViewById(R.id.fin_pr_search_button);
        fin_pr_search_button_find_near_me = (Button) findViewById(R.id.fin_pr_search_button_find_near_me);
        fin_pr_search_button.setOnClickListener(this);
        fin_pr_search_button_find_near_me.setOnClickListener(this);
        txtUserName = (TextView) findViewById(R.id.txtUserName);
        find_pr_type = (TextView) findViewById(R.id.find_pr_type);
        txtSelectedType = (TextView) findViewById(R.id.txtSelectedType);
        txtSpecilization = (TextView) findViewById(R.id.txtSpecilization);
        txtLocation = (TextView) findViewById(R.id.txtLocation);
        txtAutoLocation = (TextView) findViewById(R.id.txtAutoLocation);

        sph = new SharedPrefHelper(this);
        Gson gsn = new Gson();
        String js = sph.getString("USERDATA", "");
        UserData mUserData = gsn.fromJson(js, UserData.class);
        txtUserName.setText("Hi " + mUserData.getUsername());

        relSpecialization = (RelativeLayout) findViewById(R.id.relSpecialization);
        relLocation = (RelativeLayout) findViewById(R.id.relLocation);
        relType = (RelativeLayout) findViewById(R.id.relType);

        relSpecialization.setOnClickListener(this);
        relLocation.setOnClickListener(this);
        relType.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        Intent intent;
        switch (id) {
            case R.id.fin_pr_search_button:
                if ((GlobalVars.SelectedSpecialization.size() > 0) || (GlobalVars.SelectedType.size() > 0))
                    startActivity(new Intent(FindProfessionActivity.this, NearByProfessinals.class));
                else
                   Toast.makeText(this, "Enter search criteria",Toast.LENGTH_SHORT );
                break;

            case R.id.relLocation:
                GlobalVars.Location = "";
                startActivity(new Intent(FindProfessionActivity.this, SelectLocationActivity.class));
                break;

            case R.id.relSpecialization:
                GlobalVars.SelectedSpecialization.clear();
                startActivity(new Intent(FindProfessionActivity.this, SelectSpecializationActivity.class));
                break;
            case R.id.relType:
                GlobalVars.SelectedType.clear();
                GlobalVars.SelectedSpecialization.clear();
                startActivity(new Intent(FindProfessionActivity.this, SelectTypeActivity.class));
                break;
            case R.id.fin_pr_search_button_find_near_me:
                 startActivity(new Intent(FindProfessionActivity.this, NearByProfessinalsMap.class));
                break;


        }
    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
