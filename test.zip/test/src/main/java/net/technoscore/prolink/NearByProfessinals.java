package net.technoscore.prolink;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.FindNearMeResultList;
import net.technoscore.prolink.model.ResponseMetaSearchNear;
import net.technoscore.prolink.model.UserData;
import net.technoscore.prolink.model.filtermodel.Locationhelper;
import net.technoscore.prolink.util.GlobalVars;
import net.technoscore.prolink.util.SharedPrefHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by Vijay on 2/25/2016.
 */
public class NearByProfessinals extends AppCompatActivity {

    Spinner spnProfessional, spnDistance;
    AutoCompleteTextView edtLocation;
    private ArrayAdapter<String> LocationAdapter;
    private ArrayAdapter<String> mArrayAdapter;
    private RecyclerView mRecyclerView;
    private net.technoscore.prolink.adapter.NearByProfessinalAdapter adapter;

    GetPlaces task;
    private ApiService mApiService;

    Dialog progress;
    SharedPrefHelper sph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.near_by_list);
        setupactionbar("Professionals");
        init();
        sph = new SharedPrefHelper(this);


        BindData();


    }

    public void init() {
        spnProfessional = (Spinner) findViewById(R.id.spnProfessional);
        spnDistance = (Spinner) findViewById(R.id.spnDistance);
        edtLocation = (AutoCompleteTextView) findViewById(R.id.edtLocation);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view_near_me);
        mRecyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        ArrayList<String> distance = new ArrayList<String>();
        distance.add("Radius");
        distance.add("2");
        distance.add("6");
        distance.add("8");


        ArrayList<String> professional = new ArrayList<String>();
        professional.add("Professional");
        professional.add("Advocate");
        professional.add("Doctor");
        professional.add("Teacher");


        BindSpinners(spnProfessional, professional);
        BindSpinners(spnDistance, distance);


        LocationAdapter = new ArrayAdapter<String>(this,
                R.layout.location_items);
        LocationAdapter.setNotifyOnChange(true);
        edtLocation.setAdapter(LocationAdapter);
        TextChangedListener(edtLocation, LocationAdapter);


        ProgressBar pbar = new ProgressBar(this, null,
                android.R.attr.progressBarStyleLarge);
        pbar.setBackgroundColor(getResources().getColor(
                android.R.color.transparent));
        int padding = getResources().getDimensionPixelOffset(
                R.dimen.activity_vertical_margin);
        pbar.setPadding(padding, padding, padding, padding);

        progress = new Dialog(this);
        progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        progress.setContentView(pbar);
        progress.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));


    }


    public void BindData() {
        Gson gsn = new Gson();
        String js = sph.getString("USERDATA", "");
        UserData objUserData = gsn.fromJson(js, UserData.class);
        String token = objUserData.getToken();
        String UserID = objUserData.getUserId();


        ApiService mApiService = Singleton.getInstance().getApi();
        progress.show();
        mApiService.findNearMe(token, UserID, GlobalVars.lattitude + "", GlobalVars.longitude + "", "100", "", "", "", "", "")
                .enqueue(new Callback<AbstractResponseList<ResponseMetaSearchNear,
                        FindNearMeResultList>>() {

                    @Override
                    public void onResponse(Response<AbstractResponseList<ResponseMetaSearchNear,
                            FindNearMeResultList>> response) {

                        ResponseMetaSearchNear metaData = response.body().getResponseMeta();
                        List<FindNearMeResultList> searchResult = response.body().getData();


                        Log.d("NearByProfessinals", "metaData = " + metaData.getCode()
                                + " message = " + metaData.getMessage() + " getCurrentPage =" + metaData.getCurrentPage()
                                + " getTotalPages " + metaData.getTotalPages() + " getTotalRecord " + metaData.getTotalRecord());

                        adapter = new net.technoscore.prolink.adapter.NearByProfessinalAdapter(NearByProfessinals.this, searchResult);
                        mRecyclerView.setAdapter(adapter);

                        Log.d("NearByProfessinals", "onResponse = " + response.code());
                        progress.dismiss();

                    }

                    @Override
                    public void onFailure(Throwable t) {

                        Log.d("NearByProfessinals", "onFailure = " + t.getMessage());
                        progress.dismiss();

                    }
                });

    }

    private void setupactionbar(String title) {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        TextView toolbarTitle = (TextView) findViewById(R.id.txtTitle);
        ImageView search_image = (ImageView) findViewById(R.id.image_back);
        toolbarTitle.setText(title);
        search_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void BindSpinners(Spinner spinner, ArrayList<String> dataList) {
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapterDistance = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                dataList);
        // Drop down layout style - list view with radio button
        dataAdapterDistance.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapterDistance);
    }


    private void TextChangedListener(final AutoCompleteTextView EditLocation,
                                     final ArrayAdapter<String> adapter) {
        // TODO Auto-generated method stub
        EditLocation.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                // TODO Auto-generated method stub
                if (count % 3 == 1) {

                    Log.d("Data", EditLocation.getText().toString());
                    adapter.clear();
                    mArrayAdapter = adapter;
                    task = new GetPlaces(EditLocation.getText().toString(),
                            EditLocation);

                    task.execute((Locationhelper) null);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });
    }

    private class GetPlaces extends
            AsyncTask<Locationhelper, Void, ArrayList<Locationhelper>> {
        String searchString = "";

        AutoCompleteTextView PlaceEditLocation;

        GetPlaces(String searchText, AutoCompleteTextView editLocation) {
            searchString = searchText;
            PlaceEditLocation = editLocation;
        }

        @Override
        // three dots is java for an array of strings
        protected ArrayList<Locationhelper> doInBackground(
                Locationhelper... args) {
            //   Log.d("gottaGo", "doInBackground");
            ArrayList<Locationhelper> predictionsArr = new ArrayList<Locationhelper>();
            try {
                // https://maps.googleapis.com/maps/api/place/autocomplete/json?input=Delhi&key=AIzaSyBN43li9BMtXBKfCVujxzUZH2IMlCUQF9g
                URL googlePlaces = new URL(
                        "https://maps.googleapis.com/maps/api/place/autocomplete/json?input="
                                + URLEncoder.encode(searchString.toString(),
                                "UTF-8")
                                + "&components=country:in&types:['(cities)']&key=AIzaSyBN43li9BMtXBKfCVujxzUZH2IMlCUQF9g");
                URLConnection tc = googlePlaces.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        tc.getInputStream()));

                String line;

                StringBuffer sb = new StringBuffer();
                // take Google's legible JSON and turn it into one big string.
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                }

                Log.d("Message", sb.toString());
                // turn that string into a JSON object
                JSONObject predictions = new JSONObject(sb.toString());
                // now get the JSON array that's inside that object
                JSONArray ja = new JSONArray(
                        predictions.getString("predictions"));

                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jo = (JSONObject) ja.get(i);
                    // add each entry to our array
                    Locationhelper location = new Locationhelper();
                    location.setAddress(jo.getString("description"));

                    JSONArray statecity = jo.getJSONArray("terms");
                    /*
                     * for(int k=0; k< statecity.length(); k++) {
					 */
                    if (statecity.length() == 3) {
                        location.setStateName(statecity.getString(1));
                    } else if (statecity.length() == 2) {
                        location.setStateName(statecity.getString(0));
                    }
                    // }

                    predictionsArr.add(location);

                }
            } catch (IOException e) {
                Log.e("YourApp", "GetPlaces : doInBackground", e);

            } catch (JSONException e) {
                Log.e("YourApp", "GetPlaces : doInBackground", e);

            }
            return predictionsArr;

        }

        // then our post

        @Override
        protected void onPostExecute(ArrayList<Locationhelper> result) {
            Log.d("YourApp", "onPostExecute : " + result.size());
            // update the adapter
            mArrayAdapter = new ArrayAdapter<String>(NearByProfessinals.this, R.layout.location_items);
            mArrayAdapter.setNotifyOnChange(true);
            // attach the adapter to textview
            PlaceEditLocation.setAdapter(mArrayAdapter);
            for (int i = 0; i < result.size(); i++) {
                mArrayAdapter.add(result.get(i).getAddress());
                mArrayAdapter.notifyDataSetChanged();
            }
            PlaceEditLocation
                    .setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent,
                                                   View view, int position, long id) {
                            // TODO Auto-generated method stub

                            Locationhelper location = (Locationhelper) PlaceEditLocation
                                    .getAdapter().getItem(position);

                            Toast.makeText(getApplicationContext(), location.getAddress(), Toast.LENGTH_SHORT).show();


                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                            // TODO Auto-generated method stub

                        }
                    });
            Log.d("YourApp", "onPostExecute : autoCompleteAdapter"
                    + mArrayAdapter.getCount());

        }

    }

}
