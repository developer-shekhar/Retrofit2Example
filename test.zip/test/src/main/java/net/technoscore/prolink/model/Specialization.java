package net.technoscore.prolink.model;

/**
 * Created by Vijay on 2/29/2016.
 */
public class Specialization {

    private String value;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
