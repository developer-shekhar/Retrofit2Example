package net.technoscore.prolink.model.queries;

/**
 * Created by Vijay on 3/2/2016.
 */
public class MyQueriesDetailsModel {

    private String[] comment_result;

    private String[] user_detail;

    private Query_data[] query_data;

    private String[] query_result;

    public String[] getComment_result ()
    {
        return comment_result;
    }

    public void setComment_result (String[] comment_result)
    {
        this.comment_result = comment_result;
    }

    public String[] getUser_detail ()
    {
        return user_detail;
    }

    public void setUser_detail (String[] user_detail)
    {
        this.user_detail = user_detail;
    }

    public Query_data[] getQuery_data ()
    {
        return query_data;
    }

    public void setQuery_data (Query_data[] query_data)
    {
        this.query_data = query_data;
    }

    public String[] getQuery_result ()
    {
        return query_result;
    }

    public void setQuery_result (String[] query_result)
    {
        this.query_result = query_result;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [comment_result = "+comment_result+", user_detail = "+user_detail+", query_data = "+query_data+", query_result = "+query_result+"]";
    }
}
