package net.technoscore.prolink.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import net.technoscore.prolink.R;
import net.technoscore.prolink.model.queries.ProfDashboardModel;

import java.util.List;

/**
 * Created by mac3 on 01/03/16.
 */
public class ProfessionListAdapter extends RecyclerView.Adapter<ProfessionListAdapter.CustomViewHolder>  {

    private List<ProfDashboardModel> profDashList;
    private Context mContext;

    public ProfessionListAdapter(Context context, List<ProfDashboardModel> profDashList) {
        this.profDashList = profDashList;
        this.mContext = context;
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.professional_list_data, null);

        CustomViewHolder viewHolder = new CustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CustomViewHolder customViewHolder, int i) {

        ProfDashboardModel nearMeResult = profDashList.get(i);


        if (nearMeResult != null) {

            /*Picasso.with(mContext).load(nearMeResult.getProfileImage()).into(customViewHolder.profile_img);

            customViewHolder.profile_name.setText(getSafeSubstring(nearMeResult.getFirstName() + " " + nearMeResult.getLastName(), 15));
            customViewHolder.profile_specilazation.setText("CA");
            customViewHolder.pr_distance.setText(nearMeResult.getDistance()+"\nkms.");
            customViewHolder.pr_yrs.setText(nearMeResult.getExperience()+"\nyrs");*/

            /*customViewHolder.txtHeading.setText(nearMeResult.getExperience()+"\nyrs");
            customViewHolder.txtDateTime.setText(nearMeResult.getExperience()+"\nyrs");
            customViewHolder.txtDescription.setText(nearMeResult.getExperience()+"\nyrs");*/

        }


    }


    public String getSafeSubstring(String s, int maxLength){
        if(!TextUtils.isEmpty(s)){
            if(s.length() >= maxLength){
                return s.substring(0, maxLength)+"...";
            }
        }
        return s;
    }

    @Override
    public int getItemCount() {
        return (null != profDashList ? profDashList.size() : 0);
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {


        protected TextView txtHeading;
        protected TextView txtDateTime;
        protected TextView txtDescription;
        protected Button btnViewDetail;
        protected Button btnBookMark;
        protected Button btnAssignTo;


        public CustomViewHolder(View view) {
            super(view);

            this.txtHeading = (TextView) view.findViewById(R.id.txtHeading);
            this.txtDateTime = (TextView) view.findViewById(R.id.txtDateTime);
            this.txtDescription = (TextView) view.findViewById(R.id.txtDescription);

            this.btnViewDetail = (Button) view.findViewById(R.id.btnViewDetail);
            this.btnBookMark = (Button) view.findViewById(R.id.btnBookMark);
            this.btnAssignTo = (Button) view.findViewById(R.id.btnAssignTo);

        }
    }



}
