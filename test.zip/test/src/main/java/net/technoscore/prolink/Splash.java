package net.technoscore.prolink;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;

import net.technoscore.prolink.api.ApiService;
import net.technoscore.prolink.model.AbstractResponseList;
import net.technoscore.prolink.model.ClientRegisterData;
import net.technoscore.prolink.model.ErrorResponse;
import net.technoscore.prolink.model.ResponseMeta;
import net.technoscore.prolink.model.ResponseMetaRegistration;
import net.technoscore.prolink.model.filtermodel.FilterData;
import net.technoscore.prolink.util.GlobalVars;
import net.technoscore.prolink.util.NetworkStateReceiver;
import net.technoscore.prolink.util.SharedPrefHelper;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import retrofit2.Callback;
import retrofit2.Response;


public class Splash extends AppCompatActivity {

    private CoordinatorLayout coordinatorLayout;
    NetworkStateReceiver mNetworkStateReceiver;
    SharedPrefHelper sph;
    boolean islogin;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        createDirIfNotExists("/shashiText/test");

        init();

        islogin = sph.getBoolean("ISLOGIN", false);
        has();
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);
        mNetworkStateReceiver = new NetworkStateReceiver();
        GlobalVars.SelectedType.clear();
        GlobalVars.SelectedSpecialization.clear();

        if (!mNetworkStateReceiver.isOnline(this)) {

            showMessage("Please enable internet");
            //  Toast.makeText(this, "Please enable internet", Toast.LENGTH_LONG);
        } else {




            //Toast.makeText(getApplicationContext(),obj.getEmail(), Toast.LENGTH_SHORT).show();
            ApiService mApiService = Singleton.getInstance().getApi();
            mApiService.GetFilterData().enqueue(new Callback<AbstractResponseList<ResponseMeta, FilterData>>() {
                @Override
                public void onResponse(Response<AbstractResponseList<ResponseMeta, FilterData>> response) {
                    ResponseMeta responseMeta = response.body().getResponseMeta();
                    int code = responseMeta.getCode();
                    if (code == 200) {
                        List<FilterData> mFilterData = response.body().getData();

                        Gson gson = new Gson();
                        String json = gson.toJson(mFilterData.get(0));
                        sph.setString("FilterData", json);


                        if (islogin) {
                            Intent mIntent = new Intent(Splash.this, FindProfessionActivity.class);
                            startActivity(mIntent);
                            finish();
                        } else {
                            Intent mIntent = new Intent(Splash.this, AuthActivity.class);
                            startActivity(mIntent);
                            finish();
                        }




                    } else {
                        Toast.makeText(getApplicationContext(), responseMeta.getMessage(), Toast.LENGTH_LONG).show();
                    }

                }

                @Override
                public void onFailure(Throwable t) {
                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });




       /*     ApiService mApiService = Singleton.getInstance().getApi();

            mApiService.getClientRegister("VetmH3NVOD4wLpMANbuZ0hJlJpGtBkd1p3xoMK6QVFQ=", "Ravi", "123456789",
                    "123456789", "Ravi", "Kumar", "r@gmail.com", "9953156384", "1").enqueue(new Callback<AbstractResponseList<ResponseMetaRegistration, ClientRegisterData>>() {
                @Override
                public void onResponse(Response<AbstractResponseList<ResponseMetaRegistration, ClientRegisterData>> response) {

                    ResponseMetaRegistration responseMeta = response.body().getResponseMeta();
                    int code = responseMeta.getCode();
                    if (code == 402) {
                        List<ErrorResponse> asasa = responseMeta.getErrorResponses();
                        for (int i = 0; i < asasa.size(); i++) {
                            Toast.makeText(getApplicationContext(), asasa.get(i).getError(), Toast.LENGTH_SHORT).show();
                        }
                    }else if(code==200)
                    {Toast.makeText(getApplicationContext(),"Registration done", Toast.LENGTH_SHORT).show();

                    }
                    Log.d("Response meta", responseMeta.getMessage() + " "+ responseMeta.getCode() + " "+  responseMeta.getErrorResponses()+"");

                }

                @Override
                public void onFailure(Throwable t) {
                    Log.d("onFailure", t.getMessage() + "");
                    Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                   // progress.dismiss();
                }
            });
*/


         /*   Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (islogin) {
                        Intent mIntent = new Intent(Splash.this, FindProfessionActivity.class);
                        startActivity(mIntent);
                        finish();
                    } else {
                        Intent mIntent = new Intent(Splash.this, AuthActivity.class);
                        startActivity(mIntent);
                        finish();
                    }

                }
            }, 3000);*/


        }

     /*   5f8d4f62b649e18c83e71455600766&userid=1070&user_name=paiduser&first_name=Testfirstname&
                last_name=testlastname&address=Rajpath+Area+Central+Secretariat+New+Delhi+Delhi+India
                &city=kuldipgope@mailinator.com&zip_code=8377891399&state=0&profile_summary=
        &user_email=paid_cs@mailinator.com&phone=4543534534&phone_alt=
        &profession=2&other=other+data+is+here&qualifies=&experience=&ConsultationFee=20141
                &website=&longitude=&latitude=&zoom_level=&specialization%5B0%5D=14*/


        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void has() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "net.technoscore.prolink",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }

    }

    public void showMessage(String message) {
        Snackbar snackbar = Snackbar
                .make(coordinatorLayout, message, Snackbar.LENGTH_INDEFINITE)
                .setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        checkInternet();
                    }
                });

        snackbar.setActionTextColor(Color.BLACK);
        View sbView = snackbar.getView();

        //sbView.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
        sbView.setBackgroundColor(ContextCompat.getColor(this, R.color.white));

        CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) sbView.getLayoutParams();
        params.gravity = Gravity.TOP;
        sbView.setLayoutParams(params);
        TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.BLACK);

        snackbar.show();
    }

    public void checkInternet() {
        if (!mNetworkStateReceiver.isOnline(Splash.this)) {
            showMessage("Please enable internet");
        } else {


        }
    }

    public void init() {
        sph = new SharedPrefHelper(this);
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Splash Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Splash Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://net.technoscore.prolink/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }

    public  boolean createDirIfNotExists(String path) {
        isExternalStorageWritable();
        isExternalStorageReadable();

        boolean ret = true;
        try {
            File file = new File(Environment.getExternalStorageDirectory(), path);

            if (!file.exists()) {
                if (!file.mkdirs()) {
                    Log.e("TravellerLog :: ", "Problem creating  folder");
                    ret = false;
                }
            }
            return ret;
        }catch (Exception ex){
            Log.e("TravellerLog :: ", ex.getMessage());
        }

         return false;
    }

    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            Log.e("isWritable", "true");
            return true;
        }
        Log.e("isWritable", "false");
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            Log.e("isReadable", "true");

            return true;
        }
        Log.e("isReadable", "false");
        return false;
    }
}