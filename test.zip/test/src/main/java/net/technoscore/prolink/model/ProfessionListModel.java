package net.technoscore.prolink.model;

/**
 * Created by Vijay on 2/25/2016.
 */
public class ProfessionListModel {

    private String professionName;

    public boolean isSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public String getProfessionName() {
        return professionName;
    }

    public void setProfessionName(String professionName) {
        this.professionName = professionName;
    }

    private boolean isSelected;
}
